import { useEffect, useMemo, useState } from "react";
import {
  MapContainer,
  TileLayer,
  Circle,
  CircleMarker,
  GeoJSON,
  Popup,
  LayersControl,
  useMap,
} from "react-leaflet";
import { motion, AnimatePresence } from "motion/react";
import {
  ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, Legend, CartesianGrid,
} from "recharts";
import {
  Map as MapIcon,
  ShoppingBag,
  LogOut,
  ShieldCheck,
  UserRound,
  SlidersHorizontal,
  Droplets,
  Building2,
  Landmark,
  Waves,
  ThermometerSun,
  Wind,
  AlertTriangle,
  MessageCircle,
  X,
  Send,
  Leaf,
  ArrowRight,
  CheckCircle2,
  Navigation,
  Activity,
  Info,
  Menu,
  Mountain,
  ExternalLink,
  Save,
} from "lucide-react";
import "leaflet/dist/leaflet.css";
import "./App.css";
import { api, useApi, supabase, supabaseConfigured, fetchNearbyAmenities, money, titleCase } from "./lib/api";
import {
  RepositoryPage, SchemeFinderPage, MarketTrendsPage, PolicyMonitoringPage,
  CalculatorPage, AssistantPage, useChat, ChatMessages, Status,
} from "./pages/DataPages";

const CENTER = [12.9716, 77.5946]; // Bengaluru; maps auto-fit to the data shown

const landColors = {
  Commercial: "#f59e0b",
  Agricultural: "#22c55e",
  Government: "#8b5cf6",
  Industrial: "#64748b",
  Residential: "#06b6d4",
  "Mixed Use": "#ec4899",
};

const SQFT_PER_ACRE = 43560;
const acresLabel = (a) =>
  a == null ? "-" : `${Number(a).toLocaleString("en-IN")} acres (${Math.round(a * SQFT_PER_ACRE).toLocaleString("en-IN")} sq ft)`;

// Groundwater depth (m below ground) -> availability band used by the filter
const waterBand = (depth) => (depth == null ? "Unknown" : depth < 25 ? "High" : depth <= 45 ? "Medium" : "Low");

function FitBounds({ points, watch }) {
  const map = useMap();
  useEffect(() => {
    if (!points.length) return;
    if (points.length === 1) map.setView(points[0], 14);
    else map.fitBounds(points, { padding: [40, 40], maxZoom: 13 });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [watch, points.length]);
  return null;
}

function FlyTo({ position, zoom = 14 }) {
  const map = useMap();
  useEffect(() => {
    if (position) map.flyTo(position, zoom, { duration: 0.8 });
  }, [position, zoom, map]);
  return null;
}

function MapBase({ children, zoom = 11 }) {
  return (
    <MapContainer
      center={CENTER}
      zoom={zoom}
      scrollWheelZoom
      className="leaflet-map"
    >
      <LayersControl position="topright">
        <LayersControl.BaseLayer checked name="Street map">
          <TileLayer
            attribution="&copy; OpenStreetMap contributors"
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          />
        </LayersControl.BaseLayer>

        <LayersControl.BaseLayer name="Humanitarian">
          <TileLayer
            attribution="&copy; OpenStreetMap contributors, HOT"
            url="https://{s}.tile.openstreetmap.fr/hot/{z}/{x}/{y}.png"
          />
        </LayersControl.BaseLayer>
      </LayersControl>

      {children}
    </MapContainer>
  );
}

function Login({ onGuest }) {
  const [role, setRole] = useState("Public");
  const [mode, setMode] = useState("signin");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [info, setInfo] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(event) {
    event.preventDefault();
    setError("");
    setInfo("");

    if (!email.trim() || !password.trim()) {
      setError("Enter an email and password to continue.");
      return;
    }
    if (!supabase) {
      setError("Supabase is not configured (see .env). Use 'Continue as guest' for the demo.");
      return;
    }
    if (mode === "signup" && password.length < 6) {
      setError("Password must be at least 6 characters.");
      return;
    }

    localStorage.setItem("bhuminet-portal", role);
    setBusy(true);
    try {
      if (mode === "signup") {
        const { data, error: err } = await supabase.auth.signUp({
          email, password, options: { data: { display_name: name || email.split("@")[0] } },
        });
        if (err) throw err;
        if (!data.session) setInfo("Account created. Check your email to confirm, then sign in.");
      } else {
        const { error: err } = await supabase.auth.signInWithPassword({ email, password });
        if (err) throw err;
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="login-page">
      <motion.section
        className="login-art"
        initial={{ opacity: 0, x: -25 }}
        animate={{ opacity: 1, x: 0 }}
      >
        <div className="brand-mark">
          <Leaf size={22} /> BhuMiNet
        </div>

        <span className="eyebrow light">
          LAND INTELLIGENCE • BETTER DECISIONS
        </span>

        <h1>
          Make every parcel
          <br />
          <em>count.</em>
        </h1>

        <p>
          Explore land, understand environmental conditions, and make
          informed decisions with a connected geospatial workspace.
        </p>

        <div className="login-art-stats">
          <div>
            <strong>GIS</strong>
            <span>Map-led insights</span>
          </div>
          <div>
            <strong>360°</strong>
            <span>Land context</span>
          </div>
          <div>
            <strong>2 km</strong>
            <span>Amenities view</span>
          </div>
        </div>

        <div className="login-orbit orbit-one" />
        <div className="login-orbit orbit-two" />
      </motion.section>

      <motion.section
        className="login-card"
        initial={{ opacity: 0, y: 18 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.12 }}
      >
        <div className="login-icon">
          <ShieldCheck size={24} />
        </div>

        <h2>{mode === "signin" ? "Welcome back" : "Create account"}</h2>
        <p className="muted">
          {mode === "signin" ? "Sign in to your BhuMiNet workspace" : "Join BhuMiNet to list land and save scenarios"}
        </p>

        <div className="role-toggle">
          <button
            className={role === "Public" ? "selected" : ""}
            onClick={() => setRole("Public")}
            type="button"
          >
            <UserRound size={17} /> Public user
          </button>

          <button
            className={role === "Policymaker" ? "selected" : ""}
            onClick={() => setRole("Policymaker")}
            type="button"
          >
            <Landmark size={17} /> Policymaker
          </button>
        </div>

        <form onSubmit={submit}>
          {mode === "signup" && (
            <label>
              Display name
              <input value={name} onChange={(event) => setName(event.target.value)} placeholder="Your name" />
            </label>
          )}

          <label>
            Email address
            <input
              type="email"
              value={email}
              onChange={(event) => setEmail(event.target.value)}
              placeholder="you@example.com"
            />
          </label>

          <label>
            Password
            <input
              type="password"
              value={password}
              onChange={(event) => setPassword(event.target.value)}
              placeholder="Enter your password"
            />
          </label>

          {error && <p className="form-error">{error}</p>}
          {info && <p className="saved-message"><CheckCircle2 size={16} /> {info}</p>}

          <button className="primary-btn full" type="submit" disabled={busy}>
            {busy ? "Please wait…" : mode === "signin" ? `Sign in as ${role}` : "Create account"} <ArrowRight size={17} />
          </button>
        </form>

        <button className="text-btn full" type="button" onClick={() => setMode(mode === "signin" ? "signup" : "signin")}>
          {mode === "signin" ? "New here? Create an account" : "Already have an account? Sign in"}
        </button>

        <button className="guest-btn full" type="button" onClick={() => { localStorage.setItem("bhuminet-portal", role); onGuest(role); }}>
          Continue as guest ({role === "Policymaker" ? "policymaker demo" : "public"})
        </button>

        <p className="login-note">
          <Info size={14} />
          {role === "Policymaker"
            ? "Policymaker portal opens in demo mode. Verified policymaker access is granted only by an administrator."
            : "Guests can explore everything; sign in to list land or save scenarios."}
        </p>
      </motion.section>
    </main>
  );
}

function GISPage() {
  const [q, setQ] = useState("");
  const [state, setState] = useState("Karnataka");
  const [landUse, setLandUse] = useState("All");
  const [soil, setSoil] = useState("All");
  const [water, setWater] = useState("All");
  const [showRestricted, setShowRestricted] = useState(true);
  const [selected, setSelected] = useState(null);

  const filters = useApi(() => api.parcelFilters(), []);
  const geo = useApi(() => api.parcelsGeoJSON({ state }), [state]);
  const detail = useApi(
    () => (selected ? api.parcel(selected.parcel_ref) : Promise.resolve(null)),
    [selected?.parcel_ref],
  );

  const features = geo.data?.features || [];
  const soils = [...new Set(features.map((f) => f.properties.soil_type).filter(Boolean))].sort();
  const needle = q.trim().toLowerCase();

  const filtered = features.filter(({ properties: p }) => {
    const type = titleCase(p.land_type);
    const restricted = p.land_type === "government";
    return (
      (landUse === "All" || type === landUse) &&
      (soil === "All" || p.soil_type === soil) &&
      (water === "All" || waterBand(p.groundwater_depth_m) === water) &&
      (showRestricted || !restricted) &&
      (!needle || `${p.title} ${p.parcel_ref} ${p.locality} ${p.district}`.toLowerCase().includes(needle))
    );
  });
  const points = filtered.filter((f) => f.properties.latitude != null).map((f) => [f.properties.latitude, f.properties.longitude]);
  const colorOf = (p) => (p.land_type === "government" ? "#dc2626" : landColors[titleCase(p.land_type)] || "#0d9488");
  const d = detail.data;

  return (
    <div className="page-grid">
      <aside className="filter-panel">
        <div className="panel-heading">
          <SlidersHorizontal size={18} />
          <div>
            <h3>Map filters</h3>
            <p>Refine the land layers</p>
          </div>
        </div>

        <label>
          Search parcels
          <input value={q} onChange={(event) => setQ(event.target.value)} placeholder="Locality, district or parcel ID" />
        </label>

        <label>
          State
          <select value={state} onChange={(event) => { setState(event.target.value); setSelected(null); }}>
            <option>All</option>
            {filters.data?.states.map((s) => <option key={s}>{s}</option>)}
          </select>
        </label>

        <label>
          Land-use pattern
          <select
            value={landUse}
            onChange={(event) => setLandUse(event.target.value)}
          >
            {["All", ...Object.keys(landColors)].map((item) => (
              <option key={item}>{item}</option>
            ))}
          </select>
        </label>

        <label>
          Soil type
          <select
            value={soil}
            onChange={(event) => setSoil(event.target.value)}
          >
            {["All", ...soils].map((item) => (
              <option key={item}>{item}</option>
            ))}
          </select>
        </label>

        <label>
          Groundwater availability
          <select
            value={water}
            onChange={(event) => setWater(event.target.value)}
          >
            <option>All</option>
            <option value="High">High (&lt; 25 m deep)</option>
            <option value="Medium">Medium (25-45 m)</option>
            <option value="Low">Low (&gt; 45 m)</option>
          </select>
        </label>

        <div className="filter-check">
          <span>
            <ShieldCheck size={16} /> Government / restricted land
          </span>
          <input
            type="checkbox"
            checked={showRestricted}
            onChange={(event) => setShowRestricted(event.target.checked)}
          />
        </div>

        <div className="legend">
          <h4>Land-use legend</h4>

          {Object.entries(landColors).filter(([n]) => n !== "Government").map(([name, color]) => (
            <div key={name}>
              <i style={{ background: color }} />
              {name}
            </div>
          ))}

          <div>
            <i className="legend-restricted" />
            Government / verify
          </div>
        </div>

        <button
          className="text-btn"
          onClick={() => {
            setQ("");
            setLandUse("All");
            setSoil("All");
            setWater("All");
            setShowRestricted(true);
          }}
        >
          Reset filters
        </button>
      </aside>

      <section className="map-workspace">
        <div className="map-titlebar">
          <div>
            <span className="eyebrow">SPATIAL EXPLORER</span>
            <h2>Land intelligence map</h2>
            <p>Parcel boundaries, land use and listings • choose a parcel for details</p>
          </div>

          <span className="count-pill">
            {geo.loading ? "Loading…" : `${filtered.length} parcels shown`}
          </span>
        </div>

        {geo.error && <div className="empty-state error-state"><AlertTriangle size={16} /> {geo.error.message}</div>}

        <div className="map-frame">
          <MapBase>
            <FitBounds points={points} watch={`${state}|${landUse}|${soil}|${water}|${needle}`} />
            <GeoJSON
              key={filtered.map((f) => f.properties.id).join(",")}
              data={{ type: "FeatureCollection", features: filtered.filter((f) => f.geometry?.type === "Polygon") }}
              style={(f) => ({ color: colorOf(f.properties), weight: 2, fillOpacity: 0.25 })}
              eventHandlers={{ click: (e) => setSelected(e.layer.feature.properties) }}
            />
            {filtered.map(({ properties: plot }) => (
              <CircleMarker
                key={plot.id}
                center={[plot.latitude, plot.longitude]}
                radius={selected?.id === plot.id ? 11 : 8}
                pathOptions={{
                  color: colorOf(plot),
                  fillColor: colorOf(plot),
                  fillOpacity: 0.85,
                  weight: selected?.id === plot.id ? 4 : 2,
                }}
                eventHandlers={{
                  click: () => setSelected(plot),
                }}
              >
                <Popup>
                  <strong>{plot.title}</strong>
                  <br />
                  {titleCase(plot.land_type)} · {plot.soil_type}
                  <br />
                  Groundwater: {plot.groundwater_depth_m} m deep
                  <br />
                  {plot.has_listing ? `Listed at ${money(plot.asking_price)}` : "Not listed for sale"}
                </Popup>
              </CircleMarker>
            ))}
          </MapBase>
        </div>

        <div className="map-footnote">
          <Info size={15} />
          Parcels marked DEMO are synthetic. BhumiNet does not hold official ownership records; check the state land-record portal.
        </div>

        {selected && (
          <div className="selected-detail parcel-detail">
            <button
              className="close-small"
              onClick={() => setSelected(null)}
            >
              <X size={15} />
            </button>

            <strong>{selected.title}</strong>
            <span>
              {selected.parcel_ref} · {selected.locality}, {selected.district}, {selected.state}
            </span>

            <div className="detail-chips">
              <b>{titleCase(selected.land_type)}</b>
              <b>{selected.soil_type} soil</b>
              <b><Droplets size={12} /> Groundwater {selected.groundwater_depth_m} m ({waterBand(selected.groundwater_depth_m)})</b>
              <b>{acresLabel(selected.area_value)}</b>
              {selected.is_demo && <b className="chip-demo">Synthetic demo record</b>}
            </div>

            {detail.loading && <p className="small-note">Loading parcel details…</p>}
            {d && (
              <div className="detail-grid">
                <div>
                  <small>Listing</small>
                  <p>{d.active_listings.length ? `${money(d.active_listings[0].asking_price)} · ${d.active_listings[0].verification_status}` : "Not listed"}</p>
                </div>
                <div>
                  <small>District avg. price</small>
                  <p>{d.latest_price ? `${money(d.latest_price.metric_value)}/sq ft${d.latest_price.is_demo ? " (demo)" : ""}` : "No data"}</p>
                </div>
                <div>
                  <small>Land records</small>
                  <p><a href={d.land_record_availability.portal} target="_blank" rel="noreferrer">Official portal <ExternalLink size={12} /></a></p>
                </div>
                <div>
                  <small>Relevant schemes</small>
                  <p>{d.related_schemes.slice(0, 3).map((s) => s.title.split(" (")[0]).join(", ")}</p>
                </div>
                <div className="wide">
                  <small>Source</small>
                  <p>{d.data_sources?.name}{d.data_sources?.license_info ? ` · ${d.data_sources.license_info.replace(/^SEED:\s*/, "")}` : ""}</p>
                </div>
              </div>
            )}
          </div>
        )}
      </section>
    </div>
  );
}

function BuyLandPage() {
  const [range, setRange] = useState([500000, 20000000]);
  const [amenityFilter, setAmenityFilter] = useState("All");
  const [selected, setSelected] = useState(null);
  const [nearby, setNearby] = useState({ items: [], loading: false, error: null });

  const listings = useApi(() => api.listings({ limit: 100 }), []);
  const all = (listings.data?.data || []).filter((l) => l.land_parcels?.latitude != null);
  const available = all.filter((l) => l.asking_price >= range[0] && l.asking_price <= range[1]);
  const pos = (l) => [l.land_parcels.latitude, l.land_parcels.longitude];
  const current = selected || available[0] || null;

  useEffect(() => {
    if (!current) return;
    let alive = true;
    setNearby({ items: [], loading: true, error: null });
    fetchNearbyAmenities(pos(current))
      .then((items) => alive && setNearby({ items, loading: false, error: null }))
      .catch(() => alive && setNearby({ items: [], loading: false, error: "Couldn't load OpenStreetMap amenities right now." }));
    return () => { alive = false; };
  }, [current?.id]);

  const shownAmenities = nearby.items.filter((item) => amenityFilter === "All" || item.kind === amenityFilter);
  const counts = nearby.items.reduce((a, x) => ({ ...a, [x.kind]: (a[x.kind] || 0) + 1 }), {});
  const amenityColor = (kind) => (kind === "Hospital" ? "#ef4444" : kind === "Transit" ? "#2563eb" : "#f59e0b");

  return (
    <div className="buy-layout">
      <aside className="filter-panel buy-filters">
        <div className="panel-heading">
          <ShoppingBag size={19} />
          <div>
            <h3>Find your land</h3>
            <p>Filter active listings</p>
          </div>
        </div>

        <label>
          Minimum price <strong>{money(range[0])}</strong>
          <input
            type="range"
            min="500000"
            max="20000000"
            step="100000"
            value={range[0]}
            onChange={(event) =>
              setRange([
                Math.min(Number(event.target.value), range[1]),
                range[1],
              ])
            }
          />
        </label>

        <label>
          Maximum price <strong>{money(range[1])}</strong>
          <input
            type="range"
            min="500000"
            max="20000000"
            step="100000"
            value={range[1]}
            onChange={(event) =>
              setRange([
                range[0],
                Math.max(Number(event.target.value), range[0]),
              ])
            }
          />
        </label>

        <label>
          Nearby amenities
          <select
            value={amenityFilter}
            onChange={(event) => setAmenityFilter(event.target.value)}
          >
            {["All", "Transit", "School", "Park", "Hospital"].map((item) => (
              <option key={item}>{item}</option>
            ))}
          </select>
        </label>

        <div className="nearby-note">
          <Navigation size={16} />
          <span>
            <b>2 km radius</b>
            <br />
            {nearby.loading
              ? "Loading real facilities from OpenStreetMap…"
              : nearby.error
                ? nearby.error
                : `${counts.Transit || 0} transit · ${counts.School || 0} schools · ${counts.Park || 0} parks · ${counts.Hospital || 0} health (OpenStreetMap)`}
          </span>
        </div>

        <div className="legend">
          <h4>Map legend</h4>
          <div><i style={{ background: "#0d9488" }} />Available land</div>
          <div><i style={{ background: "#2563eb" }} />Transit</div>
          <div><i style={{ background: "#f59e0b" }} />Schools & parks</div>
          <div><i style={{ background: "#ef4444" }} />Healthcare</div>
        </div>
      </aside>

      <section className="map-workspace">
        <div className="map-titlebar">
          <div>
            <span className="eyebrow">PROPERTY DISCOVERY</span>
            <h2>Buy land with confidence</h2>
            <p>Explore listed plots and nearby essentials</p>
          </div>

          <span className="count-pill">
            {listings.loading ? "Loading…" : `${available.length} available`}
          </span>
        </div>

        <div className="map-frame buy-map">
          <MapBase>
            <FitBounds points={available.map(pos)} watch={listings.data ? "loaded" : "loading"} />
            {selected && <FlyTo position={pos(selected)} />}
            {available.map((plot) => (
              <CircleMarker
                key={plot.id}
                center={pos(plot)}
                radius={current?.id === plot.id ? 11 : 8}
                pathOptions={{
                  color: "#0d9488",
                  fillColor: "#14b8a6",
                  fillOpacity: 0.9,
                  weight: 3,
                }}
                eventHandlers={{
                  click: () => setSelected(plot),
                }}
              >
                <Popup>
                  <strong>{plot.title}</strong>
                  <br />
                  {money(plot.asking_price)} · {acresLabel(plot.area_value)}
                  <br />
                  {plot.location}
                </Popup>
              </CircleMarker>
            ))}

            {shownAmenities.map((item) => (
              <CircleMarker
                key={item.id}
                center={item.position}
                radius={5}
                pathOptions={{
                  color: amenityColor(item.kind),
                  fillColor: amenityColor(item.kind),
                  fillOpacity: 1,
                  weight: 2,
                }}
              >
                <Popup>
                  <strong>{item.name}</strong>
                  <br />
                  {item.kind} · OpenStreetMap
                </Popup>
              </CircleMarker>
            ))}

            {current && (
              <Circle
                center={pos(current)}
                radius={2000}
                pathOptions={{
                  color: "#0d9488",
                  fillColor: "#14b8a6",
                  fillOpacity: 0.06,
                  dashArray: "7 6",
                }}
              />
            )}
          </MapBase>
        </div>

        <div className="map-footnote">
          <Info size={15} />
          Demo listings are synthetic and unverified; amenities are live OpenStreetMap data.
          Confirm ownership, title, zoning and site conditions independently.
        </div>

        <div className="listing-section">
          <div className="listing-heading">
            <h3>Matching properties</h3>
            <span>{available.length} results</span>
          </div>

          <Status loading={listings.loading} error={listings.error}>
            {available.length ? (
              <div className="listing-grid">
                {available.map((plot) => (
                  <button
                    className={`listing-card ${
                      current?.id === plot.id ? "active" : ""
                    }`}
                    key={plot.id}
                    onClick={() => setSelected(plot)}
                  >
                    <div className="listing-card-top">
                      <span className="available-dot">● {titleCase(plot.verification_status)}</span>
                      <span>{plot.land_parcels?.parcel_ref || `#${plot.id}`}</span>
                    </div>

                    <h4>{plot.title}</h4>
                    <strong className="listing-price">
                      {money(plot.asking_price)}
                    </strong>
                    <p>{acresLabel(plot.area_value)} · {titleCase(plot.land_parcels?.land_type)}</p>

                    <div className="listing-bottom">
                      <span>
                        <MapIcon size={14} />
                        {plot.location}
                      </span>
                      <span>
                        View on map <ArrowRight size={14} />
                      </span>
                    </div>
                  </button>
                ))}
              </div>
            ) : (
              <div className="empty-state">
                No listings match that price range. Try widening the range.
              </div>
            )}
          </Status>
        </div>
      </section>
    </div>
  );
}

const RISK_STYLE = {
  flood: { color: "#ef4444", icon: Waves, tip: "Check official flood maps, drainage and site elevation before buying or building." },
  heat: { color: "#f59e0b", icon: ThermometerSun, tip: "Tree cover, cool roofs and open space reduce heat exposure." },
  drought: { color: "#8b5cf6", icon: Droplets, tip: "Review rainfall records and plan water harvesting." },
  groundwater_stress: { color: "#7c3aed", icon: Droplets, tip: "Check groundwater depth and recharge plans with local authorities." },
  cyclone: { color: "#0ea5e9", icon: Wind, tip: "Coastal and storm exposure: verify setback and building-code rules." },
  landslide: { color: "#a16207", icon: Mountain, tip: "Avoid steep, unstable slopes; consult geological survey data." },
};
const riskStyle = (t) => RISK_STYLE[t] || { color: "#64748b", icon: AlertTriangle, tip: "Verify against official local datasets." };

function ClimatePage() {
  const [activeRisk, setActiveRisk] = useState("All");
  const risks = useApi(() => api.risks(), []);
  const all = risks.data?.data || [];
  const types = [...new Set(all.map((r) => r.risk_type))];
  const zones = all.filter((zone) => activeRisk === "All" || zone.risk_type === activeRisk);
  const worst = (t) => all.filter((r) => r.risk_type === t).sort((a, b) => b.risk_score - a.risk_score)[0];

  return (
    <div className="climate-page">
      <div className="climate-header">
        <div>
          <span className="eyebrow">ENVIRONMENTAL INTELLIGENCE</span>
          <h2>Climate & environmental risk</h2>
          <p>
            District-level screening layers to support early planning, not a substitute for
            official hazard assessments.
          </p>
        </div>

        <div className="climate-stat">
          <Activity size={20} />
          <span>
            <b>{all.length}</b>
            <small>district risk records</small>
          </span>
        </div>
      </div>

      <Status loading={risks.loading} error={risks.error}>
        <div className="risk-summary">
          {types.map((t) => {
            const w = worst(t);
            return (
              <button
                key={t}
                onClick={() => setActiveRisk(activeRisk === t ? "All" : t)}
                className={`risk-card ${activeRisk === t ? "risk-active" : ""}`}
              >
                <span className="risk-swatch" style={{ background: riskStyle(t).color }} />
                <div>
                  <small>{w.risk_level.toUpperCase()} · {w.district}</small>
                  <b>{titleCase(t)}</b>
                  <span>Tap to view on map</span>
                </div>
                <ArrowRight size={16} />
              </button>
            );
          })}
        </div>

        <div className="climate-map-layout">
          <div className="map-frame climate-map">
            <MapBase zoom={6}>
              <FitBounds points={zones.map((z) => [z.latitude, z.longitude])} watch={activeRisk + all.length} />
              {zones.map((zone) => (
                <Circle
                  key={zone.id}
                  center={[zone.latitude, zone.longitude]}
                  radius={4000 + zone.risk_score * 180}
                  pathOptions={{
                    color: riskStyle(zone.risk_type).color,
                    fillColor: riskStyle(zone.risk_type).color,
                    fillOpacity: 0.27,
                    weight: 2,
                  }}
                >
                  <Popup>
                    <strong>
                      {titleCase(zone.risk_type)} · {zone.risk_level} ({zone.risk_score}/100)
                    </strong>
                    <br />
                    {zone.district}, {zone.state}
                    <br />
                    {zone.description}
                  </Popup>
                </Circle>
              ))}
            </MapBase>
          </div>

          <aside className="risk-details">
            <h3><Waves size={18} /> Map layers & guidance</h3>
            <p className="muted">
              Circle size grows with the risk score (0-100).
            </p>

            <div className="risk-legend">
              {zones.map((zone) => (
                <div key={zone.id}>
                  <i style={{ background: riskStyle(zone.risk_type).color }} />
                  <span>{titleCase(zone.risk_type)} · {zone.district}</span>
                  <b>{titleCase(zone.risk_level)}</b>
                </div>
              ))}
            </div>

            <div className="risk-warning">
              <AlertTriangle size={18} />
              <div>
                <b>Important data note</b>
                <p>{risks.data?.notice} Circles are screening zones, not official hazard boundaries.</p>
              </div>
            </div>
          </aside>
        </div>

        <div className="climate-guidance-grid">
          {types.map((t) => {
            const s = riskStyle(t);
            const Icon = s.icon;
            const w = worst(t);
            return (
              <article key={t} className="guidance-card">
                <div className="guidance-icon" style={{ color: s.color, background: `${s.color}18` }}>
                  <Icon />
                </div>
                <span className="risk-label" style={{ color: s.color }}>
                  {titleCase(w.risk_level)} screening
                </span>
                <h3>{titleCase(t)}</h3>
                <p>{w.description}</p>
                <small>Recommended: {s.tip}</small>
              </article>
            );
          })}
        </div>
      </Status>
    </div>
  );
}

function HomePage({ setPage, role }) {
  const features = [
    {
      name: "GIS Explorer",
      desc: "Filter land use, soil, groundwater and restricted areas.",
      icon: MapIcon,
      color: "teal",
    },
    {
      name: "Buy Land",
      desc: "Browse demo listings, adjust price and inspect nearby amenities.",
      icon: ShoppingBag,
      color: "orange",
    },
    {
      name: "Climate Risk",
      desc: "Explore color-coded environmental screening layers.",
      icon: Waves,
      color: "purple",
    },
    {
      name: "Repository",
      desc: "Review land records and reference information.",
      icon: Building2,
      color: "blue",
    },
    {
      name: "Scheme Finder",
      desc: "Explore sample public programmes and eligibility guidance.",
      icon: Landmark,
      color: "green",
    },
    {
      name: role === "Public" ? "AI Assistant" : "Policy Monitoring",
      desc: "Get guided help and review planning indicators.",
      icon: Activity,
      color: "pink",
    },
  ];

  return (
    <div className="home-page">
      <section className="hero">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <span className="eyebrow light">
            SMART LAND • SUSTAINABLE FUTURES
          </span>
          <h1>
            Land decisions,
            <br />
            <em>grounded in data.</em>
          </h1>
          <p>
            Explore land-use patterns, compare available properties, and
            understand environmental context in one connected workspace.
          </p>

          <div className="hero-actions">
            <button
              className="primary-btn"
              onClick={() => setPage("GIS Explorer")}
            >
              Explore GIS map <ArrowRight size={17} />
            </button>

            <button
              className="secondary-btn"
              onClick={() =>
                setPage(role === "Public" ? "Buy Land" : "Policy Monitoring")
              }
            >
              {role === "Public" ? "Find land" : "Policy workspace"}
            </button>
          </div>
        </motion.div>

        <motion.div
          className="hero-visual"
          initial={{ opacity: 0, scale: 0.92 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.15 }}
        >
          <div className="visual-card">
            <div className="visual-card-head">
              <span><MapIcon size={17} /> LAND OVERVIEW</span>
              <span className="live-dot">DEMO</span>
            </div>

            <div className="visual-map">
              <div className="map-river" />
              <div className="plot plot-a" />
              <div className="plot plot-b" />
              <div className="plot plot-c" />
              <div className="plot plot-d" />
              <span className="map-pin pin-a" />
              <span className="map-pin pin-b" />
              <span className="map-pin pin-c" />
            </div>

            <div className="visual-stats">
              <div>
                <small>LAND LAYERS</small>
                <b>5 categories</b>
              </div>
              <div>
                <small>MAP CONTEXT</small>
                <b>Live pan & zoom</b>
              </div>
            </div>
          </div>
        </motion.div>
      </section>

      <section className="feature-section">
        <div className="section-intro">
          <span className="eyebrow">YOUR WORKSPACE</span>
          <h2>From map to meaningful action.</h2>
          <p>Choose a tool to get started.</p>
        </div>

        <div className="feature-grid">
          {features.map((feature, index) => {
            const Icon = feature.icon;

            return (
              <motion.button
                key={feature.name}
                className="feature-card"
                onClick={() => setPage(feature.name)}
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.06 }}
                whileHover={{ y: -5 }}
              >
                <span className={`feature-icon ${feature.color}`}>
                  <Icon size={22} />
                </span>
                <h3>{feature.name}</h3>
                <p>{feature.desc}</p>
                <span className="feature-link">
                  Open tool <ArrowRight size={15} />
                </span>
              </motion.button>
            );
          })}
        </div>
      </section>
    </div>
  );
}

const AREA_TO_ACRES = { "sq ft": 1 / 43560, acre: 1, guntha: 1 / 40, cent: 1 / 100, hectare: 2.47105 };

function SellLandPage({ user, onSignIn }) {
  const empty = { name: "", location: "", type: "Agricultural", area: "", unit: "sq ft", price: "", contact: "", description: "", parcel_id: "" };
  const [form, setForm] = useState(empty);
  const [saved, setSaved] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const parcels = useApi(() => api.parcels({ limit: 100 }), []);
  const mine = useApi(() => (user.isGuest ? Promise.resolve({ data: [] }) : api.listings({ mine: "true" })), [user.isGuest]);

  function update(key, value) {
    setForm((old) => ({ ...old, [key]: value }));
    setSaved("");
    setError("");
  }

  async function submit(event) {
    event.preventDefault();
    setBusy(true);
    setError("");
    try {
      const acres = Number(form.area) * AREA_TO_ACRES[form.unit];
      await api.createListing({
        title: form.name,
        location: form.location,
        area_value: Math.round(acres * 10000) / 10000,
        asking_price: Number(form.price),
        contact_details: form.contact,
        description: `[${form.type}] ${form.description}`.trim(),
        parcel_id: form.parcel_id || null,
      });
      setSaved("Listing submitted. It is pending admin review and will appear in Buy Land once approved.");
      setForm(empty);
      mine.reload();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="generic-page">
      <div className="generic-hero">
        <span className="eyebrow">PROPERTY MARKETPLACE</span>
        <h2>Sell available land</h2>
        <p>
          Submit a land listing. Every listing is reviewed by an administrator before it is
          published, and is shown as unverified until checked.
        </p>
      </div>

      {user.isGuest && (
        <div className="access-banner demo">
          <Info size={16} />
          <span>You're browsing as a guest. <button className="link-btn" onClick={onSignIn}>Sign in</button> to submit a listing.</span>
        </div>
      )}

      <form className="sell-form" onSubmit={submit}>
        <div className="sell-form-heading">
          <h3>Land listing details</h3>
          <p>Fields marked * are required.</p>
        </div>

        <fieldset className="sell-fields" disabled={user.isGuest || busy}>
          <label>
            Listing title *
            <input
              required
              minLength={3}
              value={form.name}
              onChange={(event) => update("name", event.target.value)}
              placeholder="e.g. 2-acre farm land near Hoskote"
            />
          </label>

          <label>
            Location / address *
            <input
              required
              value={form.location}
              onChange={(event) => update("location", event.target.value)}
              placeholder="Locality, district, state"
            />
          </label>

          <label>
            Land-use type
            <select
              value={form.type}
              onChange={(event) => update("type", event.target.value)}
            >
              {["Agricultural", "Commercial", "Industrial", "Residential", "Mixed Use"].map((item) => (
                <option key={item}>{item}</option>
              ))}
            </select>
          </label>

          <label>
            Area *
            <span className="inline-pair">
              <input
                required
                type="number"
                min="0.01"
                step="any"
                value={form.area}
                onChange={(event) => update("area", event.target.value)}
                placeholder="e.g. 2400"
              />
              <select value={form.unit} onChange={(event) => update("unit", event.target.value)}>
                {Object.keys(AREA_TO_ACRES).map((u) => <option key={u}>{u}</option>)}
              </select>
            </span>
          </label>

          <label>
            Expected price (₹) *
            <input
              required
              type="number"
              min="1"
              value={form.price}
              onChange={(event) => update("price", event.target.value)}
              placeholder="e.g. 1800000"
            />
          </label>

          <label>
            Contact details *
            <input
              required
              maxLength={200}
              value={form.contact}
              onChange={(event) => update("contact", event.target.value)}
              placeholder="Email or phone"
            />
          </label>

          <label>
            Link to a mapped parcel (optional)
            <select value={form.parcel_id} onChange={(event) => update("parcel_id", event.target.value)}>
              <option value="">Not linked</option>
              {parcels.data?.data.map((p) => <option key={p.id} value={p.id}>{p.parcel_ref} · {p.locality}</option>)}
            </select>
          </label>

          <label>
            Description
            <input
              maxLength={1500}
              value={form.description}
              onChange={(event) => update("description", event.target.value)}
              placeholder="Road access, water source, documents available…"
            />
          </label>
        </fieldset>

        <div className="sell-form-bottom">
          <p>
            <Info size={15} />
            Do not enter Aadhaar, bank or other sensitive personal information.
          </p>

          <button className="primary-btn" type="submit" disabled={user.isGuest || busy}>
            {busy ? "Submitting…" : "Submit listing"} <ArrowRight size={16} />
          </button>
        </div>

        {error && <p className="form-error">{error}</p>}
        {saved && (
          <p className="saved-message">
            <CheckCircle2 size={17} />
            {saved}
          </p>
        )}
      </form>

      {!user.isGuest && (
        <div className="listing-section">
          <div className="listing-heading">
            <h3>My listings</h3>
            <span>{mine.data?.data.length || 0} submitted</span>
          </div>
          <Status loading={mine.loading} error={mine.error} empty={mine.data?.data.length === 0 && "You haven't submitted any listings yet."}>
            <div className="data-table-wrap">
              <table className="data-table">
                <thead><tr><th>Title</th><th>Location</th><th>Price</th><th>Status</th><th>Verification</th></tr></thead>
                <tbody>
                  {mine.data?.data.map((l) => (
                    <tr key={l.id}>
                      <td>{l.title}</td><td>{l.location}</td><td>{money(l.asking_price)}</td>
                      <td><span className={`status-pill ${l.status}`}>{l.status}</span></td>
                      <td>{l.verification_status}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Status>
        </div>
      )}
    </div>
  );
}

function WhatIfPage({ user }) {
  const [inputs, setInputs] = useState({
    state: "Karnataka", budget_crore: 50, years: 5, stamp_duty_change_pp: 0, courts_increase_pct: 0, awareness_campaign: false,
  });
  const [result, setResult] = useState(null);
  const [error, setError] = useState("");
  const [saveMsg, setSaveMsg] = useState("");
  const ind = useApi(() => api.indicators(), []);
  const states = Object.keys(ind.data?.by_state || {});

  useEffect(() => {
    const t = setTimeout(() => {
      api.simulate(inputs).then((r) => { setResult(r); setError(""); }).catch((e) => setError(e.message));
    }, 250);
    return () => clearTimeout(t);
  }, [inputs]);

  const set = (k, v) => { setInputs((old) => ({ ...old, [k]: v })); setSaveMsg(""); };
  const o = result?.outputs;

  async function save() {
    try {
      const r = await api.simulate({ ...inputs, save: true, scenario_name: `${inputs.state}: ₹${inputs.budget_crore} cr, ${inputs.years} yrs` });
      setSaveMsg(`Saved as "${r.saved.scenario_name}"`);
    } catch (e) {
      setSaveMsg(e.message);
    }
  }

  const sliders = [
    ["budget_crore", "Extra digitisation budget", 0, 500, 10, (v) => `₹${v} cr/yr`],
    ["years", "Time horizon", 1, 10, 1, (v) => `${v} yrs`],
    ["stamp_duty_change_pp", "Stamp duty change", -3, 3, 0.5, (v) => `${v > 0 ? "+" : ""}${v} pp`],
    ["courts_increase_pct", "Dispute resolution capacity", 0, 200, 10, (v) => `+${v}%`],
  ];

  return (
    <div className="generic-page wide">
      <div className="generic-hero">
        <span className="eyebrow">PLANNING SCENARIO LAB</span>
        <h2>What-if simulator</h2>
        <p>
          Adjust land-governance policy levers and see illustrative effects on land-record
          digitisation, dispute resolution and registration revenue. Formulas and assumptions are shown below.
        </p>
      </div>

      <div className="scenario-layout">
        <aside className="scenario-controls">
          <h3><SlidersHorizontal size={18} /> Scenario controls</h3>

          <label>
            State (baseline data)
            <select value={inputs.state} onChange={(e) => set("state", e.target.value)}>
              {(states.length ? states : [inputs.state]).map((s) => <option key={s}>{s}</option>)}
            </select>
          </label>

          {sliders.map(([k, label, min, max, step, fmt]) => (
            <label key={k}>
              {label} <b>{fmt(inputs[k])}</b>
              <input type="range" min={min} max={max} step={step} value={inputs[k]} onChange={(e) => set(k, Number(e.target.value))} />
            </label>
          ))}

          <div className="filter-check">
            <span>Public awareness campaign</span>
            <input type="checkbox" checked={inputs.awareness_campaign} onChange={(e) => set("awareness_campaign", e.target.checked)} />
          </div>

          <button className="primary-btn full" onClick={save} disabled={user.isGuest} title={user.isGuest ? "Sign in to save" : ""}>
            <Save size={16} /> {user.isGuest ? "Sign in to save scenario" : "Save scenario"}
          </button>
          {saveMsg && <p className="small-note">{saveMsg}</p>}
        </aside>

        <section className="scenario-results">
          <h3>Projected outcomes after {inputs.years} years</h3>
          {error && <p className="form-error">{error}</p>}
          {!o ? <p className="muted">Running simulation…</p> : (
            <>
              <div className="scenario-metrics">
                <article>
                  <span>Land governance index</span>
                  <strong>{o.baseline.governance_index} → {o.projected.governance_index}</strong>
                  <div className="metric-track"><i style={{ width: `${o.projected.governance_index}%`, background: "#10b981" }} /></div>
                  <small>Higher is better · {o.change.governance_index >= 0 ? "+" : ""}{o.change.governance_index} pts</small>
                </article>
                <article>
                  <span>Cadastral maps digitised</span>
                  <strong>{o.baseline.cadastral}% → {o.projected.cadastral}%</strong>
                  <div className="metric-track"><i style={{ width: `${o.projected.cadastral}%`, background: "#0ea5e9" }} /></div>
                  <small>{o.years_to_full_cadastral_digitisation != null ? `100% in ~${o.years_to_full_cadastral_digitisation} yrs at this budget` : "No extra budget"}</small>
                </article>
                <article>
                  <span>Avg. dispute resolution</span>
                  <strong>{o.baseline.dispute_days} → {o.projected.dispute_days} days</strong>
                  <div className="metric-track"><i style={{ width: `${Math.min(100, (o.projected.dispute_days / o.baseline.dispute_days) * 100)}%`, background: "#f59e0b" }} /></div>
                  <small>Lower is better · target 180 days</small>
                </article>
                <article>
                  <span>Registrations / stamp revenue</span>
                  <strong>{o.registration_volume_change_pct >= 0 ? "+" : ""}{o.registration_volume_change_pct}% / {o.stamp_revenue_change_pct >= 0 ? "+" : ""}{o.stamp_revenue_change_pct}%</strong>
                  <div className="metric-track"><i style={{ width: `${Math.min(100, 50 + o.stamp_revenue_change_pct)}%`, background: "#8b5cf6" }} /></div>
                  <small>Change vs today · illustrative elasticity</small>
                </article>
              </div>

              <div className="chart-card">
                <h3>Year-by-year projection</h3>
                <ResponsiveContainer width="100%" height={260}>
                  <LineChart data={o.series} margin={{ top: 10, right: 20, left: 0, bottom: 0 }}>
                    <CartesianGrid stroke="#e4ece8" vertical={false} />
                    <XAxis dataKey="year" tickFormatter={(y) => `Y${y}`} tick={{ fontSize: 12 }} />
                    <YAxis domain={[0, 100]} tick={{ fontSize: 12 }} width={36} />
                    <Tooltip />
                    <Legend wrapperStyle={{ fontSize: 12 }} />
                    <Line dataKey="governance_index" name="Governance index" stroke="#10b981" strokeWidth={3} dot={false} />
                    <Line dataKey="cadastral" name="Cadastral %" stroke="#0ea5e9" strokeWidth={2} dot={false} />
                    <Line dataKey="records" name="Records %" stroke="#64748b" strokeWidth={2} dot={false} />
                    <Line dataKey="ulpin" name="ULPIN %" stroke="#8b5cf6" strokeWidth={2} dot={false} />
                  </LineChart>
                </ResponsiveContainer>
              </div>

              <div className="scenario-scroll">
                <article>
                  <h4>Formulas (transparent model)</h4>
                  <ul className="formula-list">
                    {Object.entries(result.formulas).map(([k, f]) => <li key={k}><b>{titleCase(k)}</b><code>{f}</code></li>)}
                  </ul>
                </article>
                <article>
                  <h4>Assumptions</h4>
                  <ul className="formula-list">
                    {Object.entries(result.assumptions).filter(([k]) => k !== "index_weights" && k !== "disclaimer").map(([k, v]) => (
                      <li key={k}><b>{titleCase(k)}</b><code>{String(v)}</code></li>
                    ))}
                  </ul>
                  <p className="small-note">{result.assumptions.disclaimer}</p>
                </article>
              </div>
            </>
          )}
        </section>
      </div>
    </div>
  );
}

function GenericPage({ title, setPage }) {
  return (
    <div className="generic-page">
      <div className="generic-hero">
        <span className="eyebrow">BHUMINET WORKSPACE</span>
        <h2>{title}</h2>
        <p>This section is coming soon.</p>
        <button className="primary-btn" onClick={() => setPage("Home")}>
          Back to dashboard <ArrowRight size={16} />
        </button>
      </div>
    </div>
  );
}

function ChatWidget() {
  const [open, setOpen] = useState(false);
  const [value, setValue] = useState("");
  const { messages, ask, busy } = useChat();
  const health = useApi(() => api.health(), []);

  function send(event) {
    event.preventDefault();
    ask(value.trim());
    setValue("");
  }

  return (
    <div className="chat-widget">
      {open && (
        <motion.div
          className="chat-window"
          initial={{ opacity: 0, y: 15, scale: 0.96 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
        >
          <div className="chat-head">
            <span className="chat-avatar">
              <MessageCircle size={17} />
            </span>

            <div>
              <b>BhuMiNet assistant</b>
              <small>{health.data?.ai ? "AI answers with sources" : "Smart search over BhumiNet data"}</small>
            </div>

            <button onClick={() => setOpen(false)} aria-label="Close chat">
              <X size={18} />
            </button>
          </div>

          <div className="chat-messages">
            <ChatMessages messages={messages} busy={busy} />
          </div>

          <form className="chat-input" onSubmit={send}>
            <input
              value={value}
              onChange={(event) => setValue(event.target.value)}
              placeholder="Ask about land or schemes…"
            />
            <button type="submit" aria-label="Send message" disabled={busy}>
              <Send size={17} />
            </button>
          </form>
        </motion.div>
      )}

      <button
        className="chat-launcher"
        onClick={() => setOpen(!open)}
        aria-label={open ? "Close assistant" : "Open assistant"}
      >
        {open ? <X size={23} /> : <MessageCircle size={23} />}
        <span>{open ? "Close" : "Ask BhuMiNet"}</span>
      </button>
    </div>
  );
}

export default function App() {
  const [user, setUser] = useState(null);
  const [checking, setChecking] = useState(Boolean(supabase));
  const [page, setPage] = useState("Home");
  const [mobileMenu, setMobileMenu] = useState(false);
  const health = useApi(() => api.health(), []);

  // Restore the Supabase session and load the real role from the backend
  useEffect(() => {
    if (!supabase) return;
    async function load(session) {
      if (!session) {
        setUser((u) => (u?.isGuest ? u : null));
        setChecking(false);
        return;
      }
      const portal = localStorage.getItem("bhuminet-portal") || "Public";
      let dbRole = "public";
      let name = session.user.email;
      try {
        const me = await api.me();
        dbRole = me.user.role;
        name = me.user.display_name;
      } catch { /* backend down: keep defaults */ }
      setUser({ role: portal, email: session.user.email, name, dbRole, isGuest: false, verified: ["policymaker", "admin"].includes(dbRole) });
      setChecking(false);
    }
    supabase.auth.getSession().then(({ data }) => load(data.session));
    const { data: sub } = supabase.auth.onAuthStateChange((_e, session) => load(session));
    return () => sub.subscription.unsubscribe();
  }, []);

  const nav =
    user?.role === "Policymaker"
      ? [
          "Home",
          "Repository",
          "What-If Simulator",
          "GIS Explorer",
          "Policy Monitoring",
          "Market Trends",
          "Climate Risk",
          "AI Assistant",
        ]
      : [
          "Home",
          "Repository",
          "GIS Explorer",
          "Sell Available Land",
          "Buy Land",
          "Climate Risk",
          "Scheme Finder",
          "Market Trends",
          "Land Calculator",
          "AI Assistant",
        ];

  const pageTitle =
    page === "Climate & Environmental Risk" ? "Climate Risk" : page;

  async function signOut() {
    if (supabase && !user?.isGuest) await supabase.auth.signOut();
    setUser(null);
    setPage("Home");
  }

  function renderPage() {
    if (pageTitle === "Home") {
      return <HomePage setPage={setPage} role={user.role} />;
    }

    if (pageTitle === "GIS Explorer") return <GISPage />;
    if (pageTitle === "Buy Land") return <BuyLandPage />;
    if (pageTitle === "Sell Available Land") return <SellLandPage user={user} onSignIn={signOut} />;
    if (pageTitle === "What-If Simulator") return <WhatIfPage user={user} />;
    if (pageTitle === "Climate Risk") return <ClimatePage />;
    if (pageTitle === "Repository") return <RepositoryPage />;
    if (pageTitle === "Scheme Finder") return <SchemeFinderPage />;
    if (pageTitle === "Market Trends") return <MarketTrendsPage />;
    if (pageTitle === "Policy Monitoring") return <PolicyMonitoringPage />;
    if (pageTitle === "Land Calculator") return <CalculatorPage />;
    if (pageTitle === "AI Assistant") return <AssistantPage />;

    return <GenericPage title={pageTitle} setPage={setPage} />;
  }

  if (checking) {
    return <div className="empty-state" style={{ margin: 40 }}>Loading BhuMiNet…</div>;
  }

  if (!user) {
    return (
      <Login
        onGuest={(role) => {
          setUser({ role, email: "guest", name: "Guest", dbRole: "public", isGuest: true, verified: false });
          setPage("Home");
        }}
      />
    );
  }

  return (
    <div className="app-shell">
      <header className="topbar">
        <button className="brand" onClick={() => setPage("Home")}>
          <span className="brand-symbol">
            <Leaf size={20} />
          </span>
          <span>
            BhuMiNet
            <small>LAND INTELLIGENCE</small>
          </span>
        </button>

        <button
          className="mobile-menu-btn"
          onClick={() => setMobileMenu(!mobileMenu)}
        >
          <Menu size={20} />
        </button>

        <nav className={mobileMenu ? "nav-links nav-open" : "nav-links"}>
          {nav.map((item) => (
            <button
              key={item}
              className={pageTitle === item ? "nav-active" : ""}
              onClick={() => {
                setPage(item);
                setMobileMenu(false);
              }}
            >
              {item}
            </button>
          ))}
        </nav>

        <div className="account-area">
          <span className="role-chip" title={user.email}>
            {user.role === "Public" ? (
              <UserRound size={14} />
            ) : (
              <Landmark size={14} />
            )}
            {user.role}
            {user.role === "Policymaker" && !user.verified ? " (demo)" : ""}
            {user.isGuest ? " · guest" : ""}
          </span>

          <button
            className="logout-btn"
            title="Sign out"
            onClick={signOut}
          >
            <LogOut size={17} />
          </button>
        </div>
      </header>

      {health.error && (
        <div className="api-down">
          <AlertTriangle size={15} /> {health.error.message}
        </div>
      )}

      <main className="main-content">
        <AnimatePresence mode="wait">
          <motion.div
            key={pageTitle}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -7 }}
            transition={{ duration: 0.2 }}
          >
            {renderPage()}
          </motion.div>
        </AnimatePresence>
      </main>

      <footer className="site-footer">
        <span>© 2026 BhuMiNet · Land intelligence for better decisions · SDG 16</span>
        <span>Demo records are synthetic · Verify official records</span>
      </footer>

      <ChatWidget />
    </div>
  );
}
