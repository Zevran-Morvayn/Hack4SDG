import { useEffect } from "react";
import { motion } from "motion/react";
import { useT } from "../lib/i18n";

/* Bhumi-Net logo: a map pin holding a land parcel split into survey plots, with a sprout */
export function Logo({ size = 22, color = "currentColor", inner = "#ffffff" }) {
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" fill="none" aria-hidden="true">
      <path d="M16 1.8c-6.3 0-11.4 5-11.4 11.2 0 8.1 11.4 17.2 11.4 17.2s11.4-9.1 11.4-17.2C27.4 6.8 22.3 1.8 16 1.8z" fill={color} />
      <rect x="9.6" y="7.4" width="12.8" height="11" rx="1.6" fill={inner} />
      <path d="M16 7.4v11M9.6 12.9h12.8" stroke={color} strokeWidth="1.4" />
      <path d="M12.8 16.7c0-1.7 1-2.6 2-2.9M12.8 16.7c-.9-.4-1.6-1.2-1.6-2.4" stroke={color} strokeWidth="1.1" strokeLinecap="round" />
    </svg>
  );
}

export function BrandName() {
  return <span className="brand-name">Bhumi<span className="brand-dash">-</span>Net</span>;
}

/* Line-art doodle behind the login text: fields, contours, a road, trees, a house and a survey pin */
export function LoginDoodle() {
  const draw = (delay) => ({
    initial: { pathLength: 0, opacity: 0 },
    animate: { pathLength: 1, opacity: 1 },
    transition: { duration: 2.2, delay, ease: "easeInOut" },
  });
  return (
    <svg className="login-doodle" viewBox="0 0 600 600" fill="none" preserveAspectRatio="xMaxYMax meet" aria-hidden="true">
      <g stroke="#8de5c6" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round">
        {/* contour lines */}
        <motion.path {...draw(0)} d="M-20 120 C 90 70, 190 160, 300 110 S 520 60, 640 120" opacity=".5" />
        <motion.path {...draw(0.2)} d="M-20 160 C 100 115, 200 200, 310 150 S 520 105, 640 165" opacity=".35" />
        <motion.path {...draw(0.4)} d="M-20 200 C 110 160, 210 240, 320 190 S 520 150, 640 210" opacity=".25" />
        {/* field parcels in perspective */}
        <motion.path {...draw(0.3)} d="M40 520 L180 330 L360 330 L330 520 Z" />
        <motion.path {...draw(0.5)} d="M330 520 L360 330 L520 330 L600 470" />
        <motion.path {...draw(0.6)} d="M110 425 L345 425 M150 372 L352 372 M255 330 L235 520 M440 330 L465 520" opacity=".7" />
        {/* crop rows */}
        <motion.path {...draw(0.9)} d="M70 500 L200 345 M95 505 L220 345 M120 510 L240 345" opacity=".45" />
        {/* winding road */}
        <motion.path {...draw(0.4)} d="M600 300 C 520 330, 560 380, 470 400 S 380 470, 420 600" strokeWidth="2" />
        <motion.path {...draw(0.7)} d="M590 315 C 525 345, 548 385, 480 410" strokeDasharray="6 8" opacity=".6" />
        {/* trees */}
        <motion.path {...draw(1)} d="M80 300 v-30 M80 272 c-14 0 -18 -22 0 -30 c18 8 14 30 0 30 M120 305 v-22 M120 285 c-10 0 -13 -16 0 -22 c13 6 10 22 0 22" />
        {/* house */}
        <motion.path {...draw(1.1)} d="M470 300 v-34 h40 v34 M464 268 l26 -20 l26 20 M484 300 v-14 h12 v14" />
        {/* survey pin */}
        <motion.path {...draw(1.3)} d="M262 300 c-14 -16 -22 -28 -22 -40 a22 22 0 0 1 44 0 c0 12 -8 24 -22 40 z M262 252 a7 7 0 1 0 0.1 0" stroke="#ffffff" strokeWidth="1.8" />
        <motion.circle cx="262" cy="303" r="10" stroke="#ffffff" initial={{ scale: 0, opacity: 0 }} animate={{ scale: [0, 1.8, 1], opacity: [0, .6, .3] }} transition={{ delay: 2.6, duration: 1.4, repeat: Infinity, repeatDelay: 1 }} />
      </g>
    </svg>
  );
}

/* Opening animation: survey grid draws, plots fill in, a pin drops, then the name appears */
const PLOTS = [
  { x: 40, y: 120, w: 70, h: 50, c: "#22c55e" },
  { x: 115, y: 120, w: 55, h: 50, c: "#06b6d4" },
  { x: 175, y: 120, w: 85, h: 50, c: "#f59e0b" },
  { x: 40, y: 175, w: 100, h: 45, c: "#06b6d4" },
  { x: 145, y: 175, w: 50, h: 45, c: "#22c55e" },
  { x: 200, y: 175, w: 60, h: 45, c: "#8b5cf6" },
];

export function Splash({ onDone }) {
  const t = useT();
  useEffect(() => {
    const id = setTimeout(onDone, 3600);
    return () => clearTimeout(id);
  }, [onDone]);

  return (
    <motion.div className="splash" onClick={onDone} initial={{ opacity: 1 }} exit={{ opacity: 0, scale: 1.04 }} transition={{ duration: 0.5 }}>
      <svg className="splash-scene" viewBox="0 0 300 250" fill="none">
        {/* survey grid lines */}
        {[120, 172.5, 220].map((y, i) => (
          <motion.line key={`h${y}`} x1="30" x2="270" y1={y} y2={y} stroke="#8de5c6" strokeWidth="1"
            initial={{ pathLength: 0 }} animate={{ pathLength: 1 }} transition={{ delay: 0.1 * i, duration: 0.6 }} />
        ))}
        {[40, 112.5, 172.5, 260].map((x, i) => (
          <motion.line key={`v${x}`} y1="110" y2="230" x1={x} x2={x} stroke="#8de5c6" strokeWidth="1"
            initial={{ pathLength: 0 }} animate={{ pathLength: 1 }} transition={{ delay: 0.3 + 0.1 * i, duration: 0.6 }} />
        ))}
        {/* plots fill in one by one */}
        {PLOTS.map((p, i) => (
          <motion.rect key={i} x={p.x} y={p.y} width={p.w} height={p.h} rx="4" fill={p.c} stroke="#ffffff" strokeWidth="1.5"
            initial={{ opacity: 0, scale: 0.6 }} animate={{ opacity: 0.85, scale: 1 }}
            style={{ transformOrigin: `${p.x + p.w / 2}px ${p.y + p.h / 2}px` }}
            transition={{ delay: 0.8 + i * 0.12, type: "spring", stiffness: 220, damping: 16 }} />
        ))}
        {/* scanning survey beam */}
        <motion.rect y="108" width="6" height="124" fill="#ffffff" opacity="0.35"
          initial={{ x: 28 }} animate={{ x: [28, 266, 28] }} transition={{ delay: 1.4, duration: 1.4, ease: "easeInOut" }} />
        {/* pin drops onto the selected plot */}
        <motion.g initial={{ y: -120, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ delay: 1.9, type: "spring", stiffness: 260, damping: 13 }}>
          <g transform="translate(200 60) scale(2.2)">
            <Logo size={32} color="#ffffff" inner="#0b6e5f" />
          </g>
        </motion.g>
        <motion.ellipse cx="235" cy="136" rx="12" ry="4" fill="#000" opacity="0.25"
          initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ delay: 2.1 }} />
      </svg>

      <motion.h1 initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 2.3, duration: 0.5 }}>
        <BrandName />
      </motion.h1>
      <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 2.6 }}>
        {t("Mapping land. Building trust.")}
      </motion.p>
      <div className="splash-bar"><motion.i initial={{ width: 0 }} animate={{ width: "100%" }} transition={{ duration: 3.4, ease: "linear" }} /></div>
      <span className="splash-skip">{t("Click anywhere to skip")}</span>
    </motion.div>
  );
}
