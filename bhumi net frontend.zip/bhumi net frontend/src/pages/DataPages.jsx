import { useMemo, useState } from "react";
import {
  ResponsiveContainer, LineChart, Line, BarChart, Bar, XAxis, YAxis, Tooltip, Legend, CartesianGrid,
} from "recharts";
import {
  Search, ExternalLink, FileText, Landmark, Database, TrendingUp, TrendingDown,
  Calculator, Info, Send, MessageCircle, ShieldCheck, AlertTriangle,
} from "lucide-react";
import { api, useApi, money, titleCase } from "../lib/api";
import { useT } from "../lib/i18n";

const SERIES_COLORS = ["#0d9488", "#2563eb", "#f59e0b", "#8b5cf6", "#ef4444", "#64748b", "#06b6d4", "#84cc16", "#ec4899", "#a16207"];

export function Status({ loading, error, empty, children }) {
  const t = useT();
  if (loading) return <div className="empty-state">{t("Loading…")}</div>;
  if (error) return <div className="empty-state error-state"><AlertTriangle size={16} /> {error.message}</div>;
  if (empty) return <div className="empty-state">{empty}</div>;
  return children;
}

function Hero({ eyebrow, title, children }) {
  return (
    <div className="generic-hero">
      <span className="eyebrow">{eyebrow}</span>
      <h2>{title}</h2>
      <p>{children}</p>
    </div>
  );
}

function SearchBar({ value, onChange, placeholder, children }) {
  const t = useT();
  return (
    <div className="data-toolbar">
      <label className="search-input">
        <Search size={16} />
        <input value={value} onChange={(e) => onChange(e.target.value)} placeholder={t(placeholder)} />
      </label>
      {children}
    </div>
  );
}

function SourceLink({ url, label = "Official source" }) {
  const t = useT();
  return url ? (
    <a className="source-link" href={url} target="_blank" rel="noreferrer">
      {t(label)} <ExternalLink size={13} />
    </a>
  ) : null;
}

/* ---------------- Repository ---------------- */
export function RepositoryPage() {
  const t = useT();
  const [tab, setTab] = useState("documents");
  const [q, setQ] = useState("");
  const docs = useApi(() => api.documents({ q }), [q]);
  const pols = useApi(() => api.policies({ q }), [q]);
  const srcs = useApi(() => api.dataSources(), []);

  return (
    <div className="generic-page">
      <Hero eyebrow={t("RESEARCH & RECORDS")} title={t("Land records & reference library")}>
        {t("Search research documents, policies and the datasets behind Bhumi-Net. Every record shows its source.")}
      </Hero>
      <SearchBar value={q} onChange={setQ} placeholder="Search documents and policies…">
        <div className="tab-row">
          {[["documents", "Documents", FileText], ["policies", "Policies & laws", Landmark], ["sources", "Data sources", Database]].map(([k, l, Icon]) => (
            <button key={k} className={tab === k ? "tab active" : "tab"} onClick={() => setTab(k)}><Icon size={15} /> {t(l)}</button>
          ))}
        </div>
      </SearchBar>

      {tab === "documents" && (
        <Status {...docs} empty={docs.data?.data.length === 0 && t("No documents match your search.")}>
          <div className="data-cards">
            {docs.data?.data.map((d) => (
              <article key={d.id}>
                <span className="generic-number">{titleCase(d.document_type || "document")}</span>
                <h3>{d.title}</h3>
                <p>{d.description}</p>
                <div className="tag-row">{d.tags.map((t) => <span key={t}>{t}</span>)}</div>
                <div className="card-foot"><small>{d.publisher}</small><SourceLink url={d.document_url} label="Open" /></div>
              </article>
            ))}
          </div>
        </Status>
      )}

      {tab === "policies" && (
        <Status {...pols} empty={pols.data?.data.length === 0 && t("No policies match your search.")}>
          <div className="data-cards">
            {pols.data?.data.map((p) => (
              <article key={p.id}>
                <span className="generic-number">{p.jurisdiction || "India"} · {p.status}</span>
                <h3>{p.title}</h3>
                <p>{p.description}</p>
                {p.objectives && <p className="small-note"><b>{t("Objectives")}:</b> {p.objectives}</p>}
                <div className="card-foot"><small>{p.issuing_body}{p.effective_date ? ` · ${t("in force")} ${p.effective_date}` : ""}</small><SourceLink url={p.official_url} /></div>
              </article>
            ))}
          </div>
        </Status>
      )}

      {tab === "sources" && (
        <Status {...srcs}>
          <div className="data-table-wrap">
            <table className="data-table">
              <thead><tr><th>{t("Source")}</th><th>{t("Type / licence")}</th><th>{t("Last checked")}</th></tr></thead>
              <tbody>
                {srcs.data?.data.map((s) => (
                  <tr key={s.id}>
                    <td>{s.source_url ? <a href={s.source_url} target="_blank" rel="noreferrer">{s.name}</a> : s.name}</td>
                    <td>{(s.license_info || "").replace(/^SEED:\s*/, "")}</td>
                    <td>{s.last_checked_at ? new Date(s.last_checked_at).toLocaleDateString("en-IN") : "-"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Status>
      )}
    </div>
  );
}

/* ---------------- Scheme Finder ---------------- */
export function SchemeFinderPage() {
  const t = useT();
  const [q, setQ] = useState("");
  const [state, setState] = useState("All");
  const filters = useApi(() => api.parcelFilters(), []);
  const schemes = useApi(() => api.schemes({ q, state }), [q, state]);

  return (
    <div className="generic-page">
      <Hero eyebrow={t("SCHEME FINDER")} title={t("Government land & rural schemes")}>
        {t("Central and state programmes related to land records, landholders and rural housing. Summaries are general; always confirm eligibility on the official portal.")}
      </Hero>
      <SearchBar value={q} onChange={setQ} placeholder="Search e.g. property card, farmers, housing…">
        <select value={state} onChange={(e) => setState(e.target.value)}>
          <option>{t("All")}</option>
          {filters.data?.states.map((s) => <option key={s}>{s}</option>)}
        </select>
      </SearchBar>
      <Status {...schemes} empty={schemes.data?.data.length === 0 && t("No schemes match your search.")}>
        <div className="data-cards two">
          {schemes.data?.data.map((s) => (
            <article key={s.id}>
              <span className="generic-number">{s.state || t("All India")}</span>
              <h3>{s.title}</h3>
              <p className="small-note">{s.department}</p>
              <p>{s.description}</p>
              <dl className="scheme-dl">
                <dt>{t("Who can apply")}</dt><dd>{s.eligibility}</dd>
                <dt>{t("Benefits")}</dt><dd>{s.benefits}</dd>
              </dl>
              <div className="card-foot"><small>{t("Verify on official portal")}</small><SourceLink url={s.application_url} label="Visit portal" /></div>
            </article>
          ))}
        </div>
      </Status>
      {schemes.data?.notice && <p className="map-footnote"><Info size={15} /> {schemes.data.notice}</p>}
    </div>
  );
}

/* ---------------- Market Trends ---------------- */
export function MarketTrendsPage() {
  const t = useT();
  const [state, setState] = useState("Karnataka");
  const [metric, setMetric] = useState("avg_price_per_sqft");
  const filters = useApi(() => api.parcelFilters(), []);
  const trends = useApi(() => api.marketTrends({ state, metric }), [state, metric]);

  const { rows, names } = useMemo(() => {
    const series = trends.data?.series || {};
    const names = Object.keys(series);
    const byPeriod = {};
    names.forEach((n) => series[n].forEach((p) => { (byPeriod[p.period] ||= { period: p.period })[n] = p.value; }));
    const rows = Object.values(byPeriod).sort((a, b) => a.period.localeCompare(b.period))
      .map((r) => ({ ...r, label: new Date(r.period).toLocaleDateString("en-IN", { month: "short", year: "2-digit" }) }));
    return { rows, names };
  }, [trends.data]);

  return (
    <div className="generic-page wide">
      <Hero eyebrow={t("MARKET PULSE")} title={t("Land price & demand trends")}>
        {t("Monthly indicative price per sq ft and demand index by district and land type. Demo series are synthetic and labelled; replace with registered transaction data for decisions.")}
      </Hero>
      <div className="data-toolbar">
        <select value={state} onChange={(e) => setState(e.target.value)}>
          <option>{t("All")}</option>
          {filters.data?.states.map((s) => <option key={s}>{s}</option>)}
        </select>
        <div className="tab-row">
          <button className={metric === "avg_price_per_sqft" ? "tab active" : "tab"} onClick={() => setMetric("avg_price_per_sqft")}>{t("Price / sq ft")}</button>
          <button className={metric === "demand_index" ? "tab active" : "tab"} onClick={() => setMetric("demand_index")}>{t("Demand index")}</button>
        </div>
      </div>
      <Status {...trends} empty={trends.data && !names.length && t("No trend data for this selection.")}>
        <div className="kpi-grid">
          {trends.data?.summary.map((s) => (
            <div className="kpi" key={s.name}>
              <small>{s.name}</small>
              <b>{metric === "avg_price_per_sqft" ? money(s.latest) : s.latest}</b>
              <span className={s.change_pct >= 0 ? "up" : "down"}>
                {s.change_pct >= 0 ? <TrendingUp size={14} /> : <TrendingDown size={14} />} {s.change_pct}% {t("in 12 months")}
              </span>
            </div>
          ))}
        </div>
        <div className="chart-card">
          <h3>{metric === "avg_price_per_sqft" ? t("Average price (₹ per sq ft)") : t("Demand index (0-100)")}</h3>
          <ResponsiveContainer width="100%" height={340}>
            <LineChart data={rows} margin={{ top: 10, right: 20, left: 0, bottom: 0 }}>
              <CartesianGrid stroke="#e4ece8" vertical={false} />
              <XAxis dataKey="label" tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 12 }} width={60} />
              <Tooltip formatter={(v) => (metric === "avg_price_per_sqft" ? money(v) : v)} />
              <Legend wrapperStyle={{ fontSize: 12 }} />
              {names.map((n, i) => <Line key={n} dataKey={n} stroke={SERIES_COLORS[i % SERIES_COLORS.length]} strokeWidth={2} dot={false} />)}
            </LineChart>
          </ResponsiveContainer>
          <p className="map-footnote"><Info size={15} /> {trends.data?.notice}</p>
        </div>
      </Status>
    </div>
  );
}

/* ---------------- Policy Monitoring ---------------- */
const PCT_INDICATORS = ["Land records computerised", "Cadastral maps digitised", "Registration offices computerised", "Parcels with ULPIN assigned"];

export function PolicyMonitoringPage() {
  const t = useT();
  const summary = useApi(() => api.policySummary(), []);
  const ind = useApi(() => api.indicators(), []);
  const states = Object.keys(ind.data?.by_state || {});
  const [picked, setPicked] = useState(null);
  const chosen = picked || states;

  const chart = PCT_INDICATORS.map((name) => {
    const row = { indicator: name.replace("Land records ", "Records ").replace("Registration offices ", "Reg. offices ").replace("Parcels with ", "") };
    chosen.forEach((s) => { row[s] = ind.data?.by_state[s]?.[name]?.value; });
    return row;
  });
  const k = summary.data?.kpis;

  return (
    <div className="generic-page wide">
      <Hero eyebrow={t("POLICY MONITORING")} title={t("Land governance dashboard")}>
        {t("Land-record digitisation progress, dispute resolution and marketplace activity across states.")}
      </Hero>
      {summary.data && (
        <div className={`access-banner ${summary.data.access_mode}`}>
          <ShieldCheck size={16} />
          <span><b>{summary.data.access_mode === "demo" ? t("Demonstration mode") : `${t("Signed in as")} ${summary.data.access_mode}`}</b> · {t("Demo mode does not verify government employment. Figures marked demo are illustrative.")}</span>
        </div>
      )}
      <Status {...summary}>
        {k && (
          <div className="kpi-grid">
            <div className="kpi"><small>{t("Avg. records computerised")}</small><b>{k.avg_records_computerised_pct}%</b></div>
            <div className="kpi"><small>{t("Avg. cadastral maps digitised")}</small><b>{k.avg_cadastral_digitised_pct}%</b></div>
            <div className="kpi"><small>{t("Avg. ULPIN coverage")}</small><b>{k.avg_ulpin_pct}%</b></div>
            <div className="kpi"><small>{t("Avg. dispute resolution")}</small><b>{k.avg_dispute_days} {t("days")}</b></div>
            <div className="kpi"><small>{t("Parcels in system")}</small><b>{k.parcels_in_system}</b></div>
            <div className="kpi"><small>{t("Listings active / pending")}</small><b>{k.active_listings} / {k.pending_listings}</b></div>
          </div>
        )}
      </Status>
      <Status {...ind}>
        <div className="chart-card">
          <div className="chart-head">
            <h3>{t("Compare states: digitisation progress (%)")}</h3>
            <div className="chip-select">
              {states.map((s) => (
                <button key={s} className={chosen.includes(s) ? "on" : ""}
                  onClick={() => setPicked(chosen.includes(s) ? chosen.filter((x) => x !== s) : [...chosen, s])}>{s}</button>
              ))}
            </div>
          </div>
          <ResponsiveContainer width="100%" height={320}>
            <BarChart data={chart} margin={{ top: 10, right: 20, left: 0, bottom: 0 }}>
              <CartesianGrid stroke="#e4ece8" vertical={false} />
              <XAxis dataKey="indicator" tick={{ fontSize: 11 }} />
              <YAxis domain={[0, 100]} tick={{ fontSize: 12 }} width={40} />
              <Tooltip formatter={(v) => `${v}%`} />
              <Legend wrapperStyle={{ fontSize: 12 }} />
              {chosen.map((s, i) => <Bar key={s} dataKey={s} fill={SERIES_COLORS[i % SERIES_COLORS.length]} radius={[4, 4, 0, 0]} />)}
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className="data-table-wrap">
          <table className="data-table">
            <thead><tr><th>{t("State")}</th>{PCT_INDICATORS.map((n) => <th key={n}>{t(n)}</th>)}<th>{t("Avg. dispute resolution")}</th></tr></thead>
            <tbody>
              {states.map((s) => (
                <tr key={s}>
                  <td><b>{s}</b></td>
                  {PCT_INDICATORS.map((n) => {
                    const v = ind.data.by_state[s][n]?.value;
                    return <td key={n}><div className="mini-bar"><i style={{ width: `${v}%` }} /></div>{v}%</td>;
                  })}
                  <td>{ind.data.by_state[s]["Avg. land dispute resolution time"]?.value} {t("days")} <small className="muted">({t("target")} 180)</small></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="map-footnote"><Info size={15} /> {ind.data?.notice}</p>
      </Status>
    </div>
  );
}

/* ---------------- Land Calculator ---------------- */
const UNITS = ["sqft", "sqm", "sqyd", "acre", "hectare", "guntha", "cent", "bigha"];

export function CalculatorPage() {
  const t = useT();
  const [value, setValue] = useState(1);
  const [unit, setUnit] = useState("acre");
  const [price, setPrice] = useState(3500);
  const [duty, setDuty] = useState(5);
  const [reg, setReg] = useState(1);
  const conv = useApi(() => api.convertArea(Number(value) || 0, unit), [value, unit]);
  const sqft = conv.data?.conversions.sqft || 0;
  const est = useApi(
    () => (sqft > 0 && price > 0 ? api.estimateValue({ area_sqft: sqft, price_per_sqft: Number(price), stamp_duty_pct: Number(duty), registration_pct: Number(reg) }) : Promise.resolve(null)),
    [sqft, price, duty, reg],
  );

  return (
    <div className="generic-page">
      <Hero eyebrow={t("LAND CALCULATOR")} title={t("Area converter & cost estimator")}>
        {t("Convert between Indian land units and estimate indicative purchase cost including stamp duty and registration.")}
      </Hero>
      <div className="calc-grid">
        <section className="chart-card">
          <h3><Calculator size={17} /> {t("Area conversion")}</h3>
          <div className="calc-row">
            <input type="number" min="0" value={value} onChange={(e) => setValue(e.target.value)} />
            <select value={unit} onChange={(e) => setUnit(e.target.value)}>{UNITS.map((u) => <option key={u}>{u}</option>)}</select>
          </div>
          <Status {...conv}>
            <div className="conv-grid">
              {conv.data && Object.entries(conv.data.conversions).map(([u, v]) => (
                <div key={u} className={u === unit ? "on" : ""}><small>{t(u)}</small><b>{v.toLocaleString("en-IN")}</b></div>
              ))}
            </div>
            <p className="small-note">{t("Bigha and guntha sizes vary by state; check local norms.")}</p>
          </Status>
        </section>
        <section className="chart-card">
          <h3>{t("Indicative cost")}</h3>
          <label>{t("Price per sq ft (₹)")}<input type="number" min="1" value={price} onChange={(e) => setPrice(e.target.value)} /></label>
          <label>{t("Stamp duty (%)")}<input type="number" min="0" max="15" step="0.5" value={duty} onChange={(e) => setDuty(e.target.value)} /></label>
          <label>{t("Registration fee (%)")}<input type="number" min="0" max="5" step="0.5" value={reg} onChange={(e) => setReg(e.target.value)} /></label>
          {est.data && (
            <div className="cost-list">
              <div><span>{t("Land value")}</span><b>{money(est.data.indicative_value)}</b></div>
              <div><span>{t("Stamp duty")}</span><b>{money(est.data.stamp_duty)}</b></div>
              <div><span>{t("Registration fee")}</span><b>{money(est.data.registration_fee)}</b></div>
              <div className="total"><span>{t("Total")}</span><b>{money(est.data.total_cost)}</b></div>
              <p className="small-note">{t("Indicative only. Actual guidance values, duty and fees vary by state and property.")}</p>
            </div>
          )}
        </section>
      </div>
    </div>
  );
}

/* ---------------- Chat (shared by widget + Assistant page) ---------------- */
export function useChat() {
  const [messages, setMessages] = useState([
    { from: "bot", text: "greeting" },
  ]);
  const [conversationId, setConversationId] = useState(null);
  const [busy, setBusy] = useState(false);

  async function ask(question) {
    if (!question.trim() || busy) return;
    setMessages((m) => [...m, { from: "user", text: question }]);
    setBusy(true);
    try {
      const r = await api.chat(question, conversationId);
      setConversationId(r.conversation_id);
      setMessages((m) => [...m, { from: "bot", text: r.answer, sources: r.sources?.slice(0, 5), mode: r.mode }]);
    } catch (e) {
      setMessages((m) => [...m, { from: "bot", text: `Sorry, I couldn't answer that: ${e.message}` }]);
    } finally {
      setBusy(false);
    }
  }
  return { messages, ask, busy };
}

export function ChatMessages({ messages, busy }) {
  const t = useT();
  return (
    <>
      {messages.map((m, i) => (
        <div key={i} className={`chat-bubble ${m.from}`}>
          <span style={{ whiteSpace: "pre-line" }}>{m.text === "greeting" ? t("Hi! I'm the Bhumi-Net assistant. Ask me about land parcels, listings, districts or government schemes.") : m.text}</span>
          {m.sources?.length > 0 && (
            <div className="chat-sources">
              {m.sources.map((s) => (
                <span key={`${s.type}-${s.id}`}>
                  {s.link?.startsWith("http") ? <a href={s.link} target="_blank" rel="noreferrer">{s.title}</a> : s.title}
                  <small> · {t(s.type)}</small>
                </span>
              ))}
            </div>
          )}
        </div>
      ))}
      {busy && <div className="chat-bubble bot">{t("Searching…")}</div>}
    </>
  );
}

export function AssistantPage() {
  const t = useT();
  const { messages, ask, busy } = useChat();
  const [value, setValue] = useState("");
  const suggestions = ["Agricultural land in Mysuru", "What is the SVAMITVA scheme?", "Residential plots in Bengaluru", "Land acquisition compensation law"];
  return (
    <div className="generic-page">
      <Hero eyebrow={t("AI ASSISTANT")} title={t("Ask Bhumi-Net")}>
        {t("Answers come from Bhumi-Net's parcels, listings, schemes, policies and documents, with sources. Uses AI when configured, otherwise smart search.")}
      </Hero>
      <div className="assistant-panel">
        <div className="suggestion-row">
          {suggestions.map((s) => <button key={s} onClick={() => ask(s)}><MessageCircle size={14} /> {s}</button>)}
        </div>
        <div className="chat-messages tall"><ChatMessages messages={messages} busy={busy} /></div>
        <form className="chat-input" onSubmit={(e) => { e.preventDefault(); ask(value); setValue(""); }}>
          <input value={value} onChange={(e) => setValue(e.target.value)} placeholder="Ask about land, schemes, districts…" />
          <button type="submit" aria-label="Send"><Send size={17} /></button>
        </form>
      </div>
    </div>
  );
}
