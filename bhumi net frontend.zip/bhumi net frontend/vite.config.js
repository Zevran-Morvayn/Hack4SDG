import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'

export default defineConfig({
  plugins: [react(), tailwindcss()],
  server: {
    // Frontend calls /api/... and Vite forwards it to the backend (no CORS issues in dev)
    proxy: { '/api': 'http://localhost:4000' },
  },
})
