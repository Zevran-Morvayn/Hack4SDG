# BhumiNet Backend (Express + Supabase)

## 1. Database (Supabase SQL Editor, in this order)
1. `supabase/01_schema.sql` (teammate's schema; skip if the tables already exist)
2. `supabase/02_security.sql` (RLS, auto-profile on signup, blocks self-promotion to admin)
3. `supabase/03_seed.sql` (demo data, labelled `is_demo = true`; safe to re-run)

> If users signed up BEFORE step 2, create their profiles once:
> `INSERT INTO profiles (id, display_name) SELECT id, split_part(email,'@',1) FROM auth.users ON CONFLICT DO NOTHING;`

Make yourself admin (SQL editor only, there is no API for it):
```sql
UPDATE profiles SET role = 'admin' WHERE id = (SELECT id FROM auth.users WHERE email = 'you@example.com');
```

## 2. Run the API
```bash
cd bhuminet-backend
npm install
cp .env.example .env      # fill SUPABASE_URL + SUPABASE_SERVICE_ROLE_KEY
npm run dev               # http://localhost:4000/api/health
```

## 3. Frontend
- Copy `frontend-client/bhuminetApi.js` into the frontend, then `npm i @supabase/supabase-js`.
- Frontend env: `VITE_API_URL` / `NEXT_PUBLIC_API_URL` = `http://localhost:4000/api`, plus the Supabase URL and **anon** key.
- Login: `supabase.auth.signUp({ email, password, options: { data: { display_name } } })`, then `api.me()` returns the role.
- Map (Leaflet): `L.geoJSON(await api.parcelsGeoJSON()).addTo(map)`

## Endpoints (all under /api)
| Method | Path | Auth |
|---|---|---|
| GET | /health, /search?q= | - |
| GET | /parcels?q&state&district&land_type&min_area&max_area&page&limit | - |
| GET | /parcels/filters, /parcels/geojson, /parcels/:ref | - |
| GET | /listings?q&min_price&max_price (`mine=true` needs login), /listings/geojson | - |
| POST | /listings (always created as pending/unverified) | login |
| DELETE | /listings/:id | owner/admin |
| GET | /schemes?q&state, /schemes/:id, /policies?q, /documents?q&type&tag | - |
| GET | /market-trends?state&district&land_type&metric, /environmental-risks, /map-layers, /data-sources | - |
| POST | /calculator/convert {value, unit}, /calculator/estimate {area_sqft, price_per_sqft} | - |
| POST | /chat {message, conversation_id?} (AI if ANTHROPIC_API_KEY is set, else search) | optional |
| GET | /policy/summary, /policy/indicators?state, /policy/compare?states=A,B, /policy/simulator/config | - (demo mode) |
| POST | /policy/simulate {state, budget_crore, years, stamp_duty_change_pp, courts_increase_pct, awareness_campaign, save?, scenario_name?} | save needs login |
| GET/DELETE | /policy/simulations | login |
| GET/PATCH | /auth/me (name only, never role) | login |
| GET/PATCH | /admin/listings, /admin/listings/:id, /admin/users, /admin/users/:id/role, /admin/audit-logs | admin |

## Roles
- `public` is the default on signup. The role always comes from the DB, never from the client.
- The policymaker portal is open in **demo mode** to everyone (responses include `access_mode: "demo"` and a disclaimer). Only an admin can grant `policymaker`.
- Users cannot change their own role: enforced in the API **and** by a DB trigger plus RLS.

## Data honesty
- Parcels, prices, indicators and risks are synthetic (`is_demo = true`, "DEMO-" parcel refs).
- Schemes and policies are real programmes, described generally and linked to official portals.
- No ownership records are stored or invented.
