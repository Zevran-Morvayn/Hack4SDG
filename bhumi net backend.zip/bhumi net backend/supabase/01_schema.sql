-- ==========================================
-- BHUMINET DATABASE - FINAL SCHEMA (from teammate, unchanged)
-- ==========================================
CREATE TABLE public.profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    display_name TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'public' CHECK (role IN ('public', 'policymaker', 'admin')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE public.data_sources (
    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    name TEXT NOT NULL, source_url TEXT, license_info TEXT, last_checked_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE public.land_parcels (
    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    parcel_ref TEXT UNIQUE NOT NULL, title TEXT NOT NULL, state TEXT NOT NULL, district TEXT NOT NULL,
    locality TEXT, land_type TEXT,
    area_value NUMERIC CHECK (area_value IS NULL OR area_value >= 0),
    soil_type TEXT, groundwater_depth_m NUMERIC,
    latitude DOUBLE PRECISION, longitude DOUBLE PRECISION, geometry_geojson JSONB, description TEXT,
    source_id BIGINT REFERENCES public.data_sources(id) ON DELETE SET NULL,
    is_demo BOOLEAN NOT NULL DEFAULT FALSE, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CHECK (latitude IS NULL OR latitude BETWEEN -90 AND 90),
    CHECK (longitude IS NULL OR longitude BETWEEN -180 AND 180)
);
CREATE TABLE public.land_listings (
    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    parcel_id BIGINT REFERENCES public.land_parcels(id) ON DELETE SET NULL,
    owner_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
    title TEXT NOT NULL, location TEXT NOT NULL,
    area_value NUMERIC CHECK (area_value IS NULL OR area_value >= 0),
    asking_price NUMERIC CHECK (asking_price IS NULL OR asking_price >= 0),
    description TEXT, contact_details TEXT,
    status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'active', 'sold', 'rejected')),
    verification_status TEXT NOT NULL DEFAULT 'unverified'
        CHECK (verification_status IN ('unverified', 'pending', 'verified', 'rejected')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE public.environmental_risks (
    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    risk_type TEXT NOT NULL,
    risk_level TEXT NOT NULL CHECK (risk_level IN ('low', 'moderate', 'high', 'critical')),
    risk_score NUMERIC CHECK (risk_score IS NULL OR risk_score BETWEEN 0 AND 100),
    description TEXT, state TEXT NOT NULL, district TEXT NOT NULL,
    latitude DOUBLE PRECISION, longitude DOUBLE PRECISION,
    source_id BIGINT REFERENCES public.data_sources(id) ON DELETE SET NULL,
    observed_at TIMESTAMPTZ, is_demo BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE public.market_trends (
    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    state TEXT NOT NULL, district TEXT NOT NULL, land_type TEXT,
    metric_name TEXT NOT NULL, metric_value NUMERIC NOT NULL, unit TEXT,
    period_start DATE NOT NULL, period_end DATE,
    source_id BIGINT REFERENCES public.data_sources(id) ON DELETE SET NULL,
    is_demo BOOLEAN NOT NULL DEFAULT FALSE, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CHECK (period_end IS NULL OR period_end >= period_start)
);
CREATE TABLE public.government_schemes (
    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    title TEXT NOT NULL, department TEXT, state TEXT, description TEXT, eligibility TEXT, benefits TEXT,
    application_url TEXT, source_id BIGINT REFERENCES public.data_sources(id) ON DELETE SET NULL,
    last_verified_at TIMESTAMPTZ, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE public.policies (
    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    title TEXT NOT NULL, issuing_body TEXT, description TEXT, objectives TEXT, jurisdiction TEXT,
    effective_date DATE, status TEXT DEFAULT 'active', official_url TEXT,
    source_id BIGINT REFERENCES public.data_sources(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE public.land_documents (
    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    title TEXT NOT NULL, document_type TEXT, publisher TEXT, description TEXT,
    tags TEXT[] NOT NULL DEFAULT '{}', document_url TEXT, storage_path TEXT, publication_date DATE,
    source_id BIGINT REFERENCES public.data_sources(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE public.policy_indicators (
    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    policy_id BIGINT REFERENCES public.policies(id) ON DELETE SET NULL,
    indicator_name TEXT NOT NULL, state TEXT, district TEXT,
    metric_value NUMERIC, target_value NUMERIC, unit TEXT, period_start DATE,
    source_id BIGINT REFERENCES public.data_sources(id) ON DELETE SET NULL,
    is_demo BOOLEAN NOT NULL DEFAULT FALSE, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE public.map_layers (
    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    name TEXT NOT NULL, layer_type TEXT NOT NULL, description TEXT,
    source_id BIGINT REFERENCES public.data_sources(id) ON DELETE SET NULL,
    data_url TEXT, visibility BOOLEAN NOT NULL DEFAULT TRUE, is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE public.simulation_runs (
    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    user_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
    scenario_name TEXT NOT NULL,
    inputs JSONB NOT NULL DEFAULT '{}'::JSONB, outputs JSONB NOT NULL DEFAULT '{}'::JSONB,
    assumptions JSONB NOT NULL DEFAULT '{}'::JSONB, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE public.chat_history (
    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    user_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
    conversation_id UUID NOT NULL DEFAULT gen_random_uuid(),
    message_role TEXT NOT NULL CHECK (message_role IN ('user', 'assistant', 'system')),
    message TEXT NOT NULL, source_refs JSONB NOT NULL DEFAULT '[]'::JSONB,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE public.audit_logs (
    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    actor_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
    action TEXT NOT NULL, entity_type TEXT NOT NULL, entity_id TEXT,
    details JSONB NOT NULL DEFAULT '{}'::JSONB, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_parcels_location ON public.land_parcels(state, district);
CREATE INDEX idx_parcels_land_type ON public.land_parcels(land_type);
CREATE INDEX idx_listings_status ON public.land_listings(status);
CREATE INDEX idx_listings_owner ON public.land_listings(owner_id);
CREATE INDEX idx_risks_location ON public.environmental_risks(state, district);
CREATE INDEX idx_market_location_period ON public.market_trends(state, district, period_start);
CREATE INDEX idx_schemes_state ON public.government_schemes(state);
CREATE INDEX idx_policy_indicators_policy ON public.policy_indicators(policy_id);
CREATE INDEX idx_simulation_user ON public.simulation_runs(user_id);
CREATE INDEX idx_chat_conversation ON public.chat_history(conversation_id);
CREATE INDEX idx_audit_created ON public.audit_logs(created_at);
