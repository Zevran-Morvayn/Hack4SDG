-- ==========================================
-- BHUMINET - SECURITY: profiles trigger, role protection, RLS
-- Run AFTER 01_schema.sql (your teammate's CREATE TABLE script)
-- ==========================================

-- Helper: current user's role (SECURITY DEFINER so RLS on profiles doesn't recurse)
CREATE OR REPLACE FUNCTION public.current_role_name()
RETURNS TEXT LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT COALESCE((SELECT role FROM public.profiles WHERE id = auth.uid()), 'anon');
$$;

CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS BOOLEAN LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT public.current_role_name() = 'admin';
$$;

-- Auto-create a profile (always role 'public') when someone signs up
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.profiles (id, display_name, role)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'display_name', split_part(NEW.email, '@', 1), 'User'),
    'public'   -- NEVER trust a role sent from the client
  )
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Block role changes unless done by an admin or the service role (backend)
-- (SECURITY INVOKER on purpose: current_user must be the caller's role)
CREATE OR REPLACE FUNCTION public.prevent_role_escalation()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY INVOKER SET search_path = public AS $$
BEGIN
  IF NEW.role IS DISTINCT FROM OLD.role
     AND current_user <> 'service_role'                       -- backend API (service role key)
     AND COALESCE(auth.role(), '') <> 'service_role'
     AND session_user NOT IN ('postgres', 'supabase_admin')   -- Supabase SQL editor
     AND NOT public.is_admin() THEN
    RAISE EXCEPTION 'Only administrators can change roles';
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_prevent_role_escalation ON public.profiles;
CREATE TRIGGER trg_prevent_role_escalation
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.prevent_role_escalation();

-- ---------- Enable RLS everywhere ----------
ALTER TABLE public.profiles            ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.data_sources        ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.land_parcels        ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.land_listings       ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.environmental_risks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.market_trends       ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.government_schemes  ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.policies            ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.land_documents      ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.policy_indicators   ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.map_layers          ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.simulation_runs     ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.chat_history        ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.audit_logs          ENABLE ROW LEVEL SECURITY;

-- ---------- Profiles ----------
DROP POLICY IF EXISTS profiles_select_own ON public.profiles;
CREATE POLICY profiles_select_own ON public.profiles
  FOR SELECT USING (id = auth.uid() OR public.is_admin());

DROP POLICY IF EXISTS profiles_update_own ON public.profiles;
CREATE POLICY profiles_update_own ON public.profiles
  FOR UPDATE USING (id = auth.uid() OR public.is_admin())
  WITH CHECK (id = auth.uid() OR public.is_admin());
-- (role column itself is guarded by trg_prevent_role_escalation)

-- ---------- Public read-only reference data; admin write ----------
DO $$
DECLARE t TEXT;
BEGIN
  FOREACH t IN ARRAY ARRAY['data_sources','land_parcels','environmental_risks','market_trends',
                           'government_schemes','policies','land_documents','policy_indicators','map_layers']
  LOOP
    EXECUTE format('DROP POLICY IF EXISTS %I_public_read ON public.%I', t, t);
    EXECUTE format('CREATE POLICY %I_public_read ON public.%I FOR SELECT USING (true)', t, t);
    EXECUTE format('DROP POLICY IF EXISTS %I_admin_write ON public.%I', t, t);
    EXECUTE format('CREATE POLICY %I_admin_write ON public.%I FOR ALL USING (public.is_admin()) WITH CHECK (public.is_admin())', t, t);
  END LOOP;
END $$;

-- ---------- Listings ----------
-- Anyone sees active listings; owners see their own; admins see all
DROP POLICY IF EXISTS listings_read ON public.land_listings;
CREATE POLICY listings_read ON public.land_listings
  FOR SELECT USING (status = 'active' OR owner_id = auth.uid() OR public.is_admin());

-- Logged-in users create listings for themselves, always pending/unverified
DROP POLICY IF EXISTS listings_insert ON public.land_listings;
CREATE POLICY listings_insert ON public.land_listings
  FOR INSERT WITH CHECK (
    auth.uid() IS NOT NULL AND owner_id = auth.uid()
    AND status = 'pending' AND verification_status = 'unverified'
  );

-- Only admins moderate (approve/reject/verify)
DROP POLICY IF EXISTS listings_admin_update ON public.land_listings;
CREATE POLICY listings_admin_update ON public.land_listings
  FOR UPDATE USING (public.is_admin()) WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS listings_owner_delete ON public.land_listings;
CREATE POLICY listings_owner_delete ON public.land_listings
  FOR DELETE USING (owner_id = auth.uid() OR public.is_admin());

-- ---------- Simulations & chat: private to the user ----------
DROP POLICY IF EXISTS sim_own ON public.simulation_runs;
CREATE POLICY sim_own ON public.simulation_runs
  FOR ALL USING (user_id = auth.uid() OR public.is_admin())
  WITH CHECK (user_id = auth.uid());

DROP POLICY IF EXISTS chat_own ON public.chat_history;
CREATE POLICY chat_own ON public.chat_history
  FOR ALL USING (user_id = auth.uid() OR public.is_admin())
  WITH CHECK (user_id = auth.uid());

-- ---------- Audit logs: admin read only (backend writes with service role) ----------
DROP POLICY IF EXISTS audit_admin_read ON public.audit_logs;
CREATE POLICY audit_admin_read ON public.audit_logs
  FOR SELECT USING (public.is_admin());
