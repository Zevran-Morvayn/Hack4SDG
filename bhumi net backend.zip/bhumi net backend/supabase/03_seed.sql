-- ==========================================
-- BHUMINET - DEMO SEED DATA
-- Everything numeric/parcel-level here is SYNTHETIC (is_demo = TRUE) and labelled as such.
-- Scheme/policy rows describe real public programmes at a general level and link to
-- official portals; verify details there before quoting them. No ownership data is invented.
-- Safe to re-run: it clears only demo/seed rows first.
-- ==========================================

DELETE FROM public.land_listings WHERE parcel_id IN (SELECT id FROM public.land_parcels WHERE is_demo);
DELETE FROM public.land_parcels WHERE is_demo;
DELETE FROM public.market_trends WHERE is_demo;
DELETE FROM public.policy_indicators WHERE is_demo;
DELETE FROM public.environmental_risks WHERE is_demo;
DELETE FROM public.government_schemes WHERE source_id IN (SELECT id FROM public.data_sources WHERE license_info LIKE 'SEED:%');
DELETE FROM public.policies          WHERE source_id IN (SELECT id FROM public.data_sources WHERE license_info LIKE 'SEED:%');
DELETE FROM public.land_documents    WHERE source_id IN (SELECT id FROM public.data_sources WHERE license_info LIKE 'SEED:%');
DELETE FROM public.map_layers        WHERE source_id IN (SELECT id FROM public.data_sources WHERE license_info LIKE 'SEED:%');
DELETE FROM public.data_sources WHERE license_info LIKE 'SEED:%';

-- ---------- Data sources ----------
INSERT INTO public.data_sources (name, source_url, license_info, last_checked_at) VALUES
 ('BhumiNet Synthetic Demo Dataset', NULL, 'SEED: Synthetic, illustrative only - not official data', NOW()),
 ('Department of Land Resources (DoLR), Govt. of India', 'https://dolr.gov.in', 'SEED: Official public portal - link only', NOW()),
 ('Bhoomi - Karnataka Land Records', 'https://landrecords.karnataka.gov.in', 'SEED: Official public portal - link only', NOW()),
 ('SVAMITVA Scheme Portal', 'https://svamitva.nic.in', 'SEED: Official public portal - link only', NOW()),
 ('PM-KISAN Portal', 'https://pmkisan.gov.in', 'SEED: Official public portal - link only', NOW()),
 ('PMAY-Gramin Portal', 'https://pmayg.nic.in', 'SEED: Official public portal - link only', NOW()),
 ('India Code (Legislation)', 'https://www.indiacode.nic.in', 'SEED: Official public portal - link only', NOW()),
 ('OpenStreetMap', 'https://www.openstreetmap.org', 'SEED: ODbL 1.0', NOW());

-- ---------- Land parcels (synthetic, square boundaries generated around a centre point) ----------
WITH demo AS (SELECT id FROM public.data_sources WHERE name = 'BhumiNet Synthetic Demo Dataset'),
raw(ref, title, state, district, locality, land_type, area, soil, gw, lat, lng, descr) AS (VALUES
 ('DEMO-KA-BLR-001','Demo Parcel - Devanahalli Agricultural Plot','Karnataka','Bengaluru Rural','Devanahalli','agricultural',2.5,'Red loamy',38,13.2468,77.7120,'Synthetic agricultural parcel near airport corridor.'),
 ('DEMO-KA-BLR-002','Demo Parcel - Hoskote Residential Layout','Karnataka','Bengaluru Rural','Hoskote','residential',0.6,'Red sandy',45,13.0707,77.7982,'Synthetic residential layout plot.'),
 ('DEMO-KA-BLR-003','Demo Parcel - Whitefield Commercial Site','Karnataka','Bengaluru Urban','Whitefield','commercial',1.2,'Red loamy',60,12.9698,77.7500,'Synthetic commercial site near IT corridor.'),
 ('DEMO-KA-BLR-004','Demo Parcel - Yelahanka Mixed Use','Karnataka','Bengaluru Urban','Yelahanka','mixed_use',0.9,'Red loamy',52,13.1007,77.5963,'Synthetic mixed-use parcel.'),
 ('DEMO-KA-BLR-005','Demo Parcel - Anekal Industrial Plot','Karnataka','Bengaluru Urban','Anekal','industrial',3.4,'Laterite',48,12.7106,77.6950,'Synthetic industrial plot near industrial area.'),
 ('DEMO-KA-MYS-001','Demo Parcel - Nanjangud Farm Land','Karnataka','Mysuru','Nanjangud','agricultural',4.1,'Black cotton',22,12.1197,76.6830,'Synthetic farm parcel, canal-irrigated area.'),
 ('DEMO-KA-MYS-002','Demo Parcel - Mysuru Ring Road Residential','Karnataka','Mysuru','Hootagalli','residential',0.4,'Red sandy',35,12.3480,76.6000,'Synthetic residential plot.'),
 ('DEMO-KA-TMK-001','Demo Parcel - Tumakuru Government Land','Karnataka','Tumakuru','Kunigal','government',6.0,'Red loamy',55,13.0233,77.0270,'Synthetic government-held land parcel (illustrative).'),
 ('DEMO-MH-PUN-001','Demo Parcel - Hinjewadi Commercial','Maharashtra','Pune','Hinjewadi','commercial',1.5,'Black basaltic',40,18.5913,73.7389,'Synthetic commercial parcel.'),
 ('DEMO-MH-PUN-002','Demo Parcel - Maval Agricultural','Maharashtra','Pune','Maval','agricultural',5.2,'Black cotton',18,18.7400,73.6000,'Synthetic agricultural parcel.'),
 ('DEMO-TN-CHN-001','Demo Parcel - Sriperumbudur Industrial','Tamil Nadu','Kancheepuram','Sriperumbudur','industrial',4.8,'Alluvial',12,12.9675,79.9419,'Synthetic industrial parcel.'),
 ('DEMO-TS-HYD-001','Demo Parcel - Shamshabad Residential','Telangana','Rangareddy','Shamshabad','residential',0.7,'Red sandy',50,17.2543,78.4298,'Synthetic residential parcel.')
)
INSERT INTO public.land_parcels
 (parcel_ref, title, state, district, locality, land_type, area_value, soil_type, groundwater_depth_m,
  latitude, longitude, geometry_geojson, description, source_id, is_demo)
SELECT ref, title, state, district, locality, land_type, area, soil, gw, lat, lng,
  jsonb_build_object('type','Polygon','coordinates', jsonb_build_array(jsonb_build_array(
    jsonb_build_array(lng - d, lat - d), jsonb_build_array(lng + d, lat - d),
    jsonb_build_array(lng + d, lat + d), jsonb_build_array(lng - d, lat + d),
    jsonb_build_array(lng - d, lat - d)))),
  descr || ' [SYNTHETIC DEMO DATA - not an official record]', (SELECT id FROM demo), TRUE
FROM (SELECT *, 0.0006 + sqrt(area) * 0.0006 AS d FROM raw) r;   -- area_value unit: acres

-- ---------- Listings (synthetic, linked to demo parcels) ----------
INSERT INTO public.land_listings (parcel_id, owner_id, title, location, area_value, asking_price,
                                  description, contact_details, status, verification_status)
SELECT p.id, NULL, 'For Sale: ' || replace(p.title, 'Demo Parcel - ', ''),
       p.locality || ', ' || p.district || ', ' || p.state, p.area_value,
       round(p.area_value * CASE p.land_type
             WHEN 'commercial' THEN 9000000 WHEN 'residential' THEN 6500000
             WHEN 'industrial' THEN 4000000 WHEN 'mixed_use' THEN 7000000
             ELSE 1800000 END),
       'Illustrative demo listing. Indicative price only.',
       'Demo listing - no real seller', 'active', 'unverified'
FROM public.land_parcels p
WHERE p.is_demo AND p.land_type <> 'government';

-- ---------- Government schemes (real programmes, general descriptions, verify on official site) ----------
INSERT INTO public.government_schemes (title, department, state, description, eligibility, benefits, application_url, source_id, last_verified_at) VALUES
 ('Digital India Land Records Modernization Programme (DILRMP)', 'Department of Land Resources, Ministry of Rural Development', NULL,
  'Central programme for computerisation of land records, digitisation of cadastral maps, computerised registration and integration of textual and spatial records.',
  'Implemented by States/UTs; citizens benefit through state land-record portals.',
  'Online access to land records, reduced disputes, transparent registration. Includes the Unique Land Parcel Identification Number (ULPIN / Bhu-Aadhaar).',
  'https://dolr.gov.in', (SELECT id FROM public.data_sources WHERE name LIKE 'Department of Land Resources%'), NULL),
 ('SVAMITVA Scheme', 'Ministry of Panchayati Raj', NULL,
  'Survey of rural inhabited (abadi) areas using drone technology to provide property cards to households.',
  'Households in surveyed rural inhabited areas of participating villages.',
  'Record of rights / property card that can support access to bank credit and reduce property disputes.',
  'https://svamitva.nic.in', (SELECT id FROM public.data_sources WHERE name = 'SVAMITVA Scheme Portal'), NULL),
 ('PM-KISAN (Pradhan Mantri Kisan Samman Nidhi)', 'Ministry of Agriculture & Farmers Welfare', NULL,
  'Income support to landholding farmer families, paid by direct benefit transfer in instalments.',
  'Landholding farmer families, subject to exclusion criteria listed on the official portal.',
  'Annual income support (see official portal for current amount and instalments).',
  'https://pmkisan.gov.in', (SELECT id FROM public.data_sources WHERE name = 'PM-KISAN Portal'), NULL),
 ('Pradhan Mantri Awaas Yojana - Gramin (PMAY-G)', 'Ministry of Rural Development', NULL,
  'Assistance for construction of pucca houses for eligible rural households.',
  'Eligible houseless / kutcha-house rural households as per programme criteria.',
  'Financial assistance for house construction (see official portal for current norms).',
  'https://pmayg.nic.in', (SELECT id FROM public.data_sources WHERE name = 'PMAY-Gramin Portal'), NULL),
 ('Bhoomi - Online Land Records (Karnataka)', 'Revenue Department, Government of Karnataka', 'Karnataka',
  'Karnataka''s online land records system for RTC (Pahani) and related records.',
  'Any citizen can view land records; services as listed on the portal.',
  'Online RTC viewing, mutation status and related land record services.',
  'https://landrecords.karnataka.gov.in', (SELECT id FROM public.data_sources WHERE name = 'Bhoomi - Karnataka Land Records'), NULL);

-- ---------- Policies / laws (real titles, general summaries) ----------
INSERT INTO public.policies (title, issuing_body, description, objectives, jurisdiction, effective_date, status, official_url, source_id) VALUES
 ('Right to Fair Compensation and Transparency in Land Acquisition, Rehabilitation and Resettlement Act, 2013',
  'Parliament of India', 'Central law governing land acquisition, compensation and rehabilitation.',
  'Fair compensation, transparency, rehabilitation and resettlement of affected families.', 'India', '2014-01-01', 'active',
  'https://www.indiacode.nic.in', (SELECT id FROM public.data_sources WHERE name = 'India Code (Legislation)')),
 ('Registration Act, 1908', 'Imperial Legislative Council (in force in India)', 'Law governing registration of documents including property transfers.',
  'Provide a public record of documents and prevent fraud.', 'India', NULL, 'active',
  'https://www.indiacode.nic.in', (SELECT id FROM public.data_sources WHERE name = 'India Code (Legislation)')),
 ('Digital India Land Records Modernization Programme', 'Department of Land Resources', 'Programme for modernising land records (see schemes).',
  'Computerised, integrated, conclusive land titling over time.', 'India', NULL, 'active',
  'https://dolr.gov.in', (SELECT id FROM public.data_sources WHERE name LIKE 'Department of Land Resources%'));

-- ---------- Research / documents repository ----------
INSERT INTO public.land_documents (title, document_type, publisher, description, tags, document_url, publication_date, source_id) VALUES
 ('DILRMP - Programme information', 'programme', 'Department of Land Resources', 'Official programme pages and guidelines for land records modernisation.',
  ARRAY['land records','digitisation','ULPIN','DILRMP'], 'https://dolr.gov.in', NULL, (SELECT id FROM public.data_sources WHERE name LIKE 'Department of Land Resources%')),
 ('SVAMITVA - Scheme information', 'programme', 'Ministry of Panchayati Raj', 'Drone survey based property cards for rural abadi areas.',
  ARRAY['rural','property card','drone survey','SVAMITVA'], 'https://svamitva.nic.in', NULL, (SELECT id FROM public.data_sources WHERE name = 'SVAMITVA Scheme Portal')),
 ('Land Acquisition (RFCTLARR) Act, 2013 - text', 'legislation', 'India Code', 'Full text of the land acquisition law.',
  ARRAY['land acquisition','compensation','rehabilitation','law'], 'https://www.indiacode.nic.in', NULL, (SELECT id FROM public.data_sources WHERE name = 'India Code (Legislation)')),
 ('BhumiNet demo dataset - methodology note', 'dataset', 'BhumiNet team', 'Explains how synthetic parcels, prices and indicators in this demo were generated.',
  ARRAY['dataset','synthetic','methodology'], NULL, NULL, (SELECT id FROM public.data_sources WHERE name = 'BhumiNet Synthetic Demo Dataset'));

-- ---------- Map layers (parcel-focused GIS only; no climate, solar or dispute layers) ----------
INSERT INTO public.map_layers (name, layer_type, description, source_id, data_url, visibility, is_active) VALUES
 ('Base map', 'tile', 'OpenStreetMap base tiles (roads, facilities, boundaries visible on base map)', (SELECT id FROM public.data_sources WHERE name='OpenStreetMap'), 'https://tile.openstreetmap.org/{z}/{x}/{y}.png', TRUE, TRUE),
 ('Land parcels (demo)', 'geojson', 'Synthetic parcel boundaries served by the BhumiNet API', (SELECT id FROM public.data_sources WHERE name='BhumiNet Synthetic Demo Dataset'), '/api/parcels/geojson', TRUE, TRUE),
 ('Property listings', 'geojson', 'Active listings plotted at their parcel location', (SELECT id FROM public.data_sources WHERE name='BhumiNet Synthetic Demo Dataset'), '/api/listings/geojson', TRUE, TRUE);

-- ---------- Market trends (synthetic monthly price series, 12 months) ----------
WITH demo AS (SELECT id FROM public.data_sources WHERE name = 'BhumiNet Synthetic Demo Dataset'),
base(state, district, land_type, price, growth) AS (VALUES
 ('Karnataka','Bengaluru Urban','residential', 7200, 0.009),
 ('Karnataka','Bengaluru Urban','commercial', 11500, 0.007),
 ('Karnataka','Bengaluru Rural','residential', 3400, 0.012),
 ('Karnataka','Bengaluru Rural','agricultural', 950, 0.010),
 ('Karnataka','Mysuru','residential', 3900, 0.008),
 ('Karnataka','Mysuru','agricultural', 600, 0.006),
 ('Karnataka','Tumakuru','agricultural', 450, 0.007),
 ('Maharashtra','Pune','residential', 6800, 0.008),
 ('Tamil Nadu','Kancheepuram','industrial', 2600, 0.009),
 ('Telangana','Rangareddy','residential', 5200, 0.011)
)
INSERT INTO public.market_trends (state, district, land_type, metric_name, metric_value, unit, period_start, period_end, source_id, is_demo)
SELECT b.state, b.district, b.land_type, 'avg_price_per_sqft',
       round((b.price * power(1 + b.growth, m) * (1 + 0.015 * sin(m)))::numeric, 0), 'INR/sqft',
       (date_trunc('month', DATE '2025-10-01') + make_interval(months => m))::date,
       (date_trunc('month', DATE '2025-10-01') + make_interval(months => m + 1) - INTERVAL '1 day')::date,
       (SELECT id FROM demo), TRUE
FROM base b CROSS JOIN generate_series(0, 11) m
UNION ALL
SELECT b.state, b.district, b.land_type, 'demand_index',
       round((60 + 25 * b.growth * 100 / 1.2 + 8 * cos(m))::numeric, 1), 'index (0-100)',
       (date_trunc('month', DATE '2025-10-01') + make_interval(months => m))::date,
       (date_trunc('month', DATE '2025-10-01') + make_interval(months => m + 1) - INTERVAL '1 day')::date,
       (SELECT id FROM demo), TRUE
FROM base b CROSS JOIN generate_series(0, 11) m;

-- ---------- Policy indicators (synthetic, per state) ----------
WITH demo AS (SELECT id FROM public.data_sources WHERE name = 'BhumiNet Synthetic Demo Dataset'),
pol AS (SELECT id FROM public.policies WHERE title = 'Digital India Land Records Modernization Programme' LIMIT 1),
ind(state, rec, cad, reg, ulpin, days) AS (VALUES
 ('Karnataka',   96, 82, 99, 88, 410),
 ('Maharashtra', 94, 76, 98, 81, 455),
 ('Tamil Nadu',  97, 85, 99, 90, 390),
 ('Telangana',   93, 70, 97, 78, 470),
 ('Kerala',      89, 64, 96, 72, 520)
)
INSERT INTO public.policy_indicators (policy_id, indicator_name, state, district, metric_value, target_value, unit, period_start, source_id, is_demo)
SELECT (SELECT id FROM pol), x.name, i.state, NULL, x.val, x.target, x.unit, DATE '2026-04-01', (SELECT id FROM demo), TRUE
FROM ind i CROSS JOIN LATERAL (VALUES
  ('Land records computerised', i.rec::numeric, 100::numeric, '%'),
  ('Cadastral maps digitised', i.cad, 100, '%'),
  ('Registration offices computerised', i.reg, 100, '%'),
  ('Parcels with ULPIN assigned', i.ulpin, 100, '%'),
  ('Avg. land dispute resolution time', i.days, 180, 'days')
) AS x(name, val, target, unit);

-- ---------- Environmental risks (synthetic, separate Climate tab) ----------
INSERT INTO public.environmental_risks (risk_type, risk_level, risk_score, description, state, district, latitude, longitude, source_id, observed_at, is_demo)
SELECT r.*, (SELECT id FROM public.data_sources WHERE name='BhumiNet Synthetic Demo Dataset'), NOW() - INTERVAL '30 days', TRUE
FROM (VALUES
 ('flood','high',72::numeric,'Synthetic: urban flooding exposure in low-lying areas','Karnataka','Bengaluru Urban',12.9716,77.5946),
 ('groundwater_stress','critical',86,'Synthetic: deep groundwater table','Karnataka','Bengaluru Rural',13.2468,77.7120),
 ('drought','high',68,'Synthetic: rainfall deficit exposure','Karnataka','Tumakuru',13.3379,77.1173),
 ('heat','moderate',55,'Synthetic: heat stress days','Karnataka','Mysuru',12.2958,76.6394),
 ('flood','moderate',48,'Synthetic: riverine flood exposure','Maharashtra','Pune',18.5204,73.8567),
 ('cyclone','high',70,'Synthetic: coastal cyclone exposure','Tamil Nadu','Kancheepuram',12.8342,79.7036),
 ('heat','high',66,'Synthetic: heat stress days','Telangana','Rangareddy',17.3891,78.4983),
 ('landslide','high',74,'Synthetic: hill slope instability','Kerala','Idukki',9.8497,76.9720)
) AS r(risk_type, risk_level, risk_score, description, state, district, latitude, longitude);
