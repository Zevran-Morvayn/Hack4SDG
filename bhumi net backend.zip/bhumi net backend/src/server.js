import express from 'express';
import cors from 'cors';
import 'dotenv/config';
import { optionalAuth } from './lib/supabase.js';
import publicRoutes from './routes/public.js';
import policyRoutes from './routes/policy.js';
import chatRoutes, { searchHandler } from './routes/chat.js';
import { authRouter, adminRouter } from './routes/admin.js';

const app = express();
const origins = (process.env.CORS_ORIGINS || 'http://localhost:3000,http://localhost:5173,http://127.0.0.1:5500')
  .split(',').map((s) => s.trim());
app.use(cors({ origin: (o, cb) => cb(null, !o || origins.includes(o) || origins.includes('*')) }));
app.use(express.json({ limit: '200kb' }));
app.use(optionalAuth);

app.get('/api/health', (_req, res) => res.json({ ok: true, ai: Boolean(process.env.ANTHROPIC_API_KEY), time: new Date().toISOString() }));
app.get('/api/search', searchHandler);
app.use('/api', publicRoutes);
app.use('/api/policy', policyRoutes);
app.use('/api/chat', chatRoutes);
app.use('/api/auth', authRouter);
app.use('/api/admin', adminRouter);

app.use('/api', (_req, res) => res.status(404).json({ error: 'Not found' }));
app.use((err, _req, res, _next) => {
  if (!err.status || err.status >= 500) console.error(err);
  res.status(err.status || 500).json({ error: err.status && err.status < 500 ? err.message : 'Server error' });
});

const port = process.env.PORT || 4000;
app.listen(port, () => console.log(`BhumiNet API running on http://localhost:${port}`));
