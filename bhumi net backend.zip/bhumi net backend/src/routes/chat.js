import { Router } from 'express';
import { randomUUID } from 'node:crypto';
import { db } from '../lib/supabase.js';
import { ah, must, cleanSearch } from '../lib/util.js';

const r = Router();
const STOP = new Set(['the','a','an','is','are','what','which','how','for','in','of','to','and','me','show','tell','about','i','my','can','do','land','near','with','any','there','list','find']);

const keywords = (text) => cleanSearch(text).toLowerCase().split(/\s+/)
  .filter((w) => w.length > 2 && !STOP.has(w)).slice(0, 5);

// Search fallback: keyword search across parcels, schemes, policies, documents, listings
async function searchAll(message) {
  const words = keywords(message);
  if (!words.length) return [];
  const orOf = (cols) => words.flatMap((w) => cols.map((c) => `${c}.ilike.%${w}%`)).join(',');
  const [parcels, schemes, policies, docs, listings] = await Promise.all([
    db.from('land_parcels').select('parcel_ref, title, district, state, land_type, area_value, is_demo')
      .or(orOf(['title', 'locality', 'district', 'state', 'land_type'])).limit(5),
    db.from('government_schemes').select('id, title, description, application_url')
      .or(orOf(['title', 'description', 'benefits', 'department'])).limit(5),
    db.from('policies').select('id, title, description, official_url').or(orOf(['title', 'description', 'objectives'])).limit(3),
    db.from('land_documents').select('id, title, description, document_url').or(orOf(['title', 'description'])).limit(3),
    db.from('land_listings').select('id, title, location, asking_price').eq('status', 'active')
      .or(orOf(['title', 'location', 'description'])).limit(5),
  ]);
  const out = [];
  must(parcels).forEach((p) => out.push({ type: 'parcel', id: p.parcel_ref, title: p.title,
    snippet: `${p.land_type || ''} · ${p.area_value ?? '?'} acres · ${p.district}, ${p.state}${p.is_demo ? ' (synthetic)' : ''}`,
    link: `/parcels/${p.parcel_ref}` }));
  must(schemes).forEach((s) => out.push({ type: 'scheme', id: s.id, title: s.title, snippet: s.description, link: s.application_url }));
  must(policies).forEach((s) => out.push({ type: 'policy', id: s.id, title: s.title, snippet: s.description, link: s.official_url }));
  must(docs).forEach((s) => out.push({ type: 'document', id: s.id, title: s.title, snippet: s.description, link: s.document_url }));
  must(listings).forEach((s) => out.push({ type: 'listing', id: s.id, title: s.title,
    snippet: `${s.location} · Rs ${Number(s.asking_price || 0).toLocaleString('en-IN')}`, link: `/listings/${s.id}` }));
  return out;
}

function fallbackAnswer(results) {
  if (!results.length) {
    return 'I could not find matching records. Try a district (e.g. "Mysuru"), a land type (e.g. "agricultural") or a scheme name (e.g. "SVAMITVA").';
  }
  const counts = results.reduce((a, x) => ({ ...a, [x.type]: (a[x.type] || 0) + 1 }), {});
  const parts = Object.entries(counts).map(([t, n]) => `${n} ${t}${n > 1 ? 's' : ''}`);
  return `I found ${parts.join(', ')} related to your question. ` +
    results.slice(0, 4).map((x) => `• ${x.title}`).join('\n');
}

async function aiAnswer(message, results, history) {
  const key = process.env.ANTHROPIC_API_KEY;
  if (!key) return null;
  const context = results.map((x, i) => `[${i + 1}] (${x.type}) ${x.title}: ${x.snippet || ''} ${x.link || ''}`).join('\n');
  const resp = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'x-api-key': key, 'anthropic-version': '2023-06-01', 'content-type': 'application/json' },
    body: JSON.stringify({
      model: process.env.AI_MODEL || 'claude-sonnet-4-5',
      max_tokens: 500,
      system: 'You are the BhumiNet land information assistant for India. Answer ONLY from the provided records and general public knowledge about land schemes. '
        + 'Never invent ownership, official statistics or verification results. Say when data is synthetic demo data. '
        + 'Point users to official portals for authoritative records. Be concise.',
      messages: [
        ...history.slice(-6).map((h) => ({ role: h.message_role === 'assistant' ? 'assistant' : 'user', content: h.message })),
        { role: 'user', content: `Records found:\n${context || '(none)'}\n\nQuestion: ${message}` },
      ],
    }),
  });
  if (!resp.ok) { console.warn('AI call failed', resp.status, await resp.text()); return null; }
  const json = await resp.json();
  return json.content?.map((c) => c.text).join('') || null;
}

// POST /api/chat { message, conversation_id? }
r.post('/', ah(async (req, res) => {
  const message = String(req.body?.message || '').trim().slice(0, 1000);
  if (!message) return res.status(400).json({ error: 'message is required' });
  const isUuid = /^[0-9a-f-]{36}$/i.test(req.body?.conversation_id || '');
  const conversationId = isUuid ? req.body.conversation_id : randomUUID();

  let history = [];
  if (req.user && isUuid) {
    history = must(await db.from('chat_history').select('message_role, message')
      .eq('conversation_id', conversationId).eq('user_id', req.user.id).order('created_at').limit(20));
  }
  const results = await searchAll(message);
  let answer = null; let mode = 'search';
  try { answer = await aiAnswer(message, results, history); if (answer) mode = 'ai'; } catch (e) { console.warn(e.message); }
  if (!answer) answer = fallbackAnswer(results);

  if (req.user) { // only logged-in users get stored history
    await db.from('chat_history').insert([
      { user_id: req.user.id, conversation_id: conversationId, message_role: 'user', message },
      { user_id: req.user.id, conversation_id: conversationId, message_role: 'assistant', message: answer, source_refs: results },
    ]);
  }
  res.json({ conversation_id: conversationId, mode, answer, sources: results });
}));

// GET /api/search?q=  -> global search box (same engine, no chat)
export const searchHandler = ah(async (req, res) => {
  res.json({ q: req.query.q || '', results: await searchAll(String(req.query.q || '')) });
});

export default r;
