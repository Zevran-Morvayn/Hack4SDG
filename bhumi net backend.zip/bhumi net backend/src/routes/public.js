import { Router } from 'express';
import { db, requireAuth, audit } from '../lib/supabase.js';
import { ah, must, cleanSearch, toInt, toNum, HttpError, DEMO_NOTICE } from '../lib/util.js';
import { convertArea, estimateValue } from '../lib/calculator.js';

const r = Router();
const PARCEL_COLS = 'id, parcel_ref, title, state, district, locality, land_type, area_value, soil_type, groundwater_depth_m, latitude, longitude, description, is_demo, created_at';

// ---------- LAND PARCELS ----------
// GET /api/parcels?q=&state=&district=&land_type=&min_area=&max_area=&page=&limit=
r.get('/parcels', ah(async (req, res) => {
  const limit = toInt(req.query.limit, 20, 1, 100);
  const page = toInt(req.query.page, 1, 1, 1000);
  let qb = db.from('land_parcels').select(`${PARCEL_COLS}, data_sources(name, source_url)`, { count: 'exact' });
  const q = cleanSearch(req.query.q);
  if (q) qb = qb.or(`title.ilike.%${q}%,parcel_ref.ilike.%${q}%,locality.ilike.%${q}%,district.ilike.%${q}%,state.ilike.%${q}%`);
  if (req.query.state) qb = qb.eq('state', req.query.state);
  if (req.query.district) qb = qb.eq('district', req.query.district);
  if (req.query.land_type) qb = qb.eq('land_type', req.query.land_type);
  if (toNum(req.query.min_area) !== null) qb = qb.gte('area_value', toNum(req.query.min_area));
  if (toNum(req.query.max_area) !== null) qb = qb.lte('area_value', toNum(req.query.max_area));
  const { data, count } = must(await qb.order('id').range((page - 1) * limit, page * limit - 1));
  res.json({ data, total: count ?? data.length, page, limit, notice: DEMO_NOTICE });
}));

// GET /api/parcels/filters -> distinct states, districts, land types for dropdowns
r.get('/parcels/filters', ah(async (_req, res) => {
  const rows = must(await db.from('land_parcels').select('state, district, land_type'));
  const uniq = (k) => [...new Set(rows.map((x) => x[k]).filter(Boolean))].sort();
  const districtsByState = {};
  rows.forEach((x) => { (districtsByState[x.state] ||= new Set()).add(x.district); });
  Object.keys(districtsByState).forEach((s) => { districtsByState[s] = [...districtsByState[s]].sort(); });
  res.json({ states: uniq('state'), districts: uniq('district'), land_types: uniq('land_type'), districts_by_state: districtsByState });
}));

// GET /api/parcels/geojson?state=&district=&land_type=  -> FeatureCollection for Leaflet/Mapbox
r.get('/parcels/geojson', ah(async (req, res) => {
  let qb = db.from('land_parcels').select(`${PARCEL_COLS}, geometry_geojson`);
  if (req.query.state) qb = qb.eq('state', req.query.state);
  if (req.query.district) qb = qb.eq('district', req.query.district);
  if (req.query.land_type) qb = qb.eq('land_type', req.query.land_type);
  const rows = must(await qb.limit(2000));
  const listings = must(await db.from('land_listings').select('parcel_id, asking_price').eq('status', 'active'));
  const priceByParcel = Object.fromEntries(listings.map((l) => [l.parcel_id, l.asking_price]));
  res.json({
    type: 'FeatureCollection',
    features: rows.map(({ geometry_geojson, ...p }) => ({
      type: 'Feature',
      geometry: geometry_geojson
        || (p.latitude != null ? { type: 'Point', coordinates: [p.longitude, p.latitude] } : null),
      properties: { ...p, has_listing: p.id in priceByParcel, asking_price: priceByParcel[p.id] ?? null,
                    land_record_portal: p.state === 'Karnataka' ? 'https://landrecords.karnataka.gov.in' : 'https://dolr.gov.in' },
    })),
  });
}));

// GET /api/parcels/:ref   (parcel_ref like DEMO-KA-BLR-001, or numeric id)
r.get('/parcels/:ref', ah(async (req, res) => {
  const ref = req.params.ref;
  let qb = db.from('land_parcels').select('*, data_sources(name, source_url, license_info)');
  qb = /^\d+$/.test(ref) ? qb.eq('id', ref) : qb.eq('parcel_ref', ref);
  const parcel = must(await qb.maybeSingle());
  if (!parcel) throw new HttpError(404, 'Parcel not found');
  const [listings, schemes, trends] = await Promise.all([
    db.from('land_listings').select('id, title, asking_price, status, verification_status').eq('parcel_id', parcel.id).eq('status', 'active'),
    db.from('government_schemes').select('id, title, application_url').or(`state.is.null,state.eq."${cleanSearch(parcel.state)}"`).limit(5),
    db.from('market_trends').select('metric_name, metric_value, unit, period_start, is_demo')
      .eq('district', parcel.district).eq('metric_name', 'avg_price_per_sqft').order('period_start', { ascending: false }).limit(1),
  ]);
  res.json({
    ...parcel,
    active_listings: must(listings),
    related_schemes: must(schemes),
    latest_price: must(trends)[0] || null,
    land_record_availability: {
      note: 'BhumiNet does not hold official ownership records. Check the official state portal.',
      portal: parcel.state === 'Karnataka' ? 'https://landrecords.karnataka.gov.in' : 'https://dolr.gov.in',
    },
  });
}));

// ---------- LISTINGS ----------
// GET /api/listings?q=&min_price=&max_price=&mine=true
r.get('/listings', ah(async (req, res) => {
  const limit = toInt(req.query.limit, 20, 1, 100);
  const page = toInt(req.query.page, 1, 1, 1000);
  let qb = db.from('land_listings')
    .select('id, parcel_id, title, location, area_value, asking_price, description, status, verification_status, created_at, land_parcels(parcel_ref, land_type, latitude, longitude, is_demo)', { count: 'exact' });
  if (req.query.mine === 'true') {
    if (!req.user) throw new HttpError(401, 'Login required');
    qb = qb.eq('owner_id', req.user.id);
  } else {
    qb = qb.eq('status', 'active');
  }
  const q = cleanSearch(req.query.q);
  if (q) qb = qb.or(`title.ilike.%${q}%,location.ilike.%${q}%,description.ilike.%${q}%`);
  if (toNum(req.query.min_price) !== null) qb = qb.gte('asking_price', toNum(req.query.min_price));
  if (toNum(req.query.max_price) !== null) qb = qb.lte('asking_price', toNum(req.query.max_price));
  const { data, count } = must(await qb.order('created_at', { ascending: false }).range((page - 1) * limit, page * limit - 1));
  res.json({ data, total: count ?? data.length, page, limit });
}));

// GET /api/listings/geojson  -> active listings as map points
r.get('/listings/geojson', ah(async (_req, res) => {
  const rows = must(await db.from('land_listings')
    .select('id, title, location, asking_price, area_value, verification_status, land_parcels(latitude, longitude)')
    .eq('status', 'active'));
  res.json({
    type: 'FeatureCollection',
    features: rows.filter((l) => l.land_parcels?.latitude != null).map(({ land_parcels: p, ...l }) => ({
      type: 'Feature', geometry: { type: 'Point', coordinates: [p.longitude, p.latitude] }, properties: l,
    })),
  });
}));

// POST /api/listings  (login required) -> always created as pending/unverified
r.post('/listings', requireAuth, ah(async (req, res) => {
  const b = req.body || {};
  const errors = [];
  const title = String(b.title || '').trim();
  const location = String(b.location || '').trim();
  if (title.length < 3 || title.length > 150) errors.push('title must be 3-150 characters');
  if (location.length < 2 || location.length > 200) errors.push('location is required (max 200 chars)');
  const area = toNum(b.area_value); const price = toNum(b.asking_price);
  if (area !== null && !(area >= 0)) errors.push('area_value must be a non-negative number');
  if (price !== null && !(price >= 0)) errors.push('asking_price must be a non-negative number');
  if (b.description && String(b.description).length > 2000) errors.push('description max 2000 chars');
  if (b.contact_details && String(b.contact_details).length > 200) errors.push('contact_details max 200 chars');
  let parcelId = null;
  if (b.parcel_id !== undefined && b.parcel_id !== null && b.parcel_id !== '') {
    parcelId = Number(b.parcel_id);
    const exists = must(await db.from('land_parcels').select('id').eq('id', parcelId).maybeSingle());
    if (!exists) errors.push('parcel_id does not exist');
  }
  if (errors.length) return res.status(400).json({ error: 'Validation failed', details: errors });

  const row = must(await db.from('land_listings').insert({
    parcel_id: parcelId, owner_id: req.user.id, title, location, area_value: area, asking_price: price,
    description: b.description ? String(b.description) : null,
    contact_details: b.contact_details ? String(b.contact_details) : null,
    status: 'pending', verification_status: 'unverified', // server decides, not the client
  }).select().single());
  await audit(req.user.id, 'listing.create', 'land_listings', row.id);
  res.status(201).json({ data: row, message: 'Listing submitted for admin review.' });
}));

// DELETE /api/listings/:id  (owner or admin)
r.delete('/listings/:id', requireAuth, ah(async (req, res) => {
  const row = must(await db.from('land_listings').select('id, owner_id').eq('id', req.params.id).maybeSingle());
  if (!row) throw new HttpError(404, 'Listing not found');
  if (row.owner_id !== req.user.id && req.user.role !== 'admin') throw new HttpError(403, 'Not your listing');
  must(await db.from('land_listings').delete().eq('id', row.id));
  await audit(req.user.id, 'listing.delete', 'land_listings', row.id);
  res.json({ ok: true });
}));

// ---------- SCHEMES / POLICIES / DOCUMENTS ----------
r.get('/schemes', ah(async (req, res) => {
  let qb = db.from('government_schemes').select('*, data_sources(name, source_url)');
  if (req.query.state) qb = qb.or(`state.is.null,state.eq."${cleanSearch(req.query.state)}"`);
  const q = cleanSearch(req.query.q);
  if (q) qb = qb.or(`title.ilike.%${q}%,description.ilike.%${q}%,department.ilike.%${q}%,benefits.ilike.%${q}%`);
  res.json({ data: must(await qb.order('title')),
             notice: 'Summaries are general. Always confirm eligibility and benefits on the official portal.' });
}));

r.get('/schemes/:id', ah(async (req, res) => {
  const row = must(await db.from('government_schemes').select('*, data_sources(name, source_url)').eq('id', req.params.id).maybeSingle());
  if (!row) throw new HttpError(404, 'Scheme not found');
  res.json(row);
}));

r.get('/policies', ah(async (req, res) => {
  let qb = db.from('policies').select('*, data_sources(name, source_url)');
  const q = cleanSearch(req.query.q);
  if (q) qb = qb.or(`title.ilike.%${q}%,description.ilike.%${q}%,objectives.ilike.%${q}%`);
  if (req.query.status) qb = qb.eq('status', req.query.status);
  res.json({ data: must(await qb.order('title')) });
}));

// GET /api/documents?q=&type=&tag=
r.get('/documents', ah(async (req, res) => {
  let qb = db.from('land_documents').select('*, data_sources(name, source_url)');
  const q = cleanSearch(req.query.q);
  if (q) qb = qb.or(`title.ilike.%${q}%,description.ilike.%${q}%,publisher.ilike.%${q}%`);
  if (req.query.type) qb = qb.eq('document_type', req.query.type);
  if (req.query.tag) qb = qb.contains('tags', [req.query.tag]);
  res.json({ data: must(await qb.order('title')) });
}));

// ---------- MARKET TRENDS ----------
// GET /api/market-trends?state=&district=&land_type=&metric=avg_price_per_sqft
// Returns flat rows + a chart-ready series grouped by "district - land_type"
r.get('/market-trends', ah(async (req, res) => {
  let qb = db.from('market_trends').select('state, district, land_type, metric_name, metric_value, unit, period_start, is_demo');
  qb = qb.eq('metric_name', req.query.metric || 'avg_price_per_sqft');
  if (req.query.state) qb = qb.eq('state', req.query.state);
  if (req.query.district) qb = qb.eq('district', req.query.district);
  if (req.query.land_type) qb = qb.eq('land_type', req.query.land_type);
  const rows = must(await qb.order('period_start'));
  const series = {};
  rows.forEach((x) => {
    const key = `${x.district} - ${x.land_type}`;
    (series[key] ||= []).push({ period: x.period_start, value: Number(x.metric_value) });
  });
  const summary = Object.entries(series).map(([name, pts]) => ({
    name, latest: pts.at(-1)?.value,
    change_pct: pts.length > 1 ? Math.round(((pts.at(-1).value - pts[0].value) / pts[0].value) * 1000) / 10 : 0,
  }));
  res.json({ data: rows, series, summary, unit: rows[0]?.unit, notice: DEMO_NOTICE });
}));

// ---------- CLIMATE / ENVIRONMENT (separate tab) ----------
r.get('/environmental-risks', ah(async (req, res) => {
  let qb = db.from('environmental_risks').select('*, data_sources(name, source_url)');
  if (req.query.state) qb = qb.eq('state', req.query.state);
  if (req.query.district) qb = qb.eq('district', req.query.district);
  if (req.query.risk_type) qb = qb.eq('risk_type', req.query.risk_type);
  if (req.query.risk_level) qb = qb.eq('risk_level', req.query.risk_level);
  res.json({ data: must(await qb.order('risk_score', { ascending: false })), notice: DEMO_NOTICE });
}));

// ---------- MAP LAYERS ----------
r.get('/map-layers', ah(async (_req, res) => {
  res.json({ data: must(await db.from('map_layers').select('*, data_sources(name, source_url, license_info)').eq('is_active', true).order('id')) });
}));

r.get('/data-sources', ah(async (_req, res) => {
  res.json({ data: must(await db.from('data_sources').select('*').order('id')) });
}));

// ---------- CALCULATOR ----------
// POST /api/calculator/convert { value, unit }
r.post('/calculator/convert', (req, res) => {
  try { res.json(convertArea(req.body?.value, req.body?.unit)); }
  catch (e) { res.status(400).json({ error: e.message }); }
});
// POST /api/calculator/estimate { area_sqft, price_per_sqft, stamp_duty_pct?, registration_pct? }
r.post('/calculator/estimate', (req, res) => {
  try { res.json(estimateValue(req.body || {})); }
  catch (e) { res.status(400).json({ error: e.message }); }
});

export default r;
