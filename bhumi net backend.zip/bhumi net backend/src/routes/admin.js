import { Router } from 'express';
import { db, requireAuth, requireRole, audit } from '../lib/supabase.js';
import { ah, must, HttpError } from '../lib/util.js';

// ---------- Auth / profile (/api/auth) ----------
export const authRouter = Router();

// GET /api/auth/me -> who am I + role (frontend uses this to show/hide portals)
authRouter.get('/me', requireAuth, (req, res) => res.json({ user: req.user }));

// PATCH /api/auth/me { display_name } -> users may only change their name, never their role
authRouter.patch('/me', requireAuth, ah(async (req, res) => {
  const name = String(req.body?.display_name || '').trim();
  if (name.length < 2 || name.length > 60) throw new HttpError(400, 'display_name must be 2-60 characters');
  const row = must(await db.from('profiles').update({ display_name: name }).eq('id', req.user.id).select('id, display_name, role').single());
  res.json({ user: row });
}));

// ---------- Admin (/api/admin) ----------
export const adminRouter = Router();
adminRouter.use(requireRole('admin'));

adminRouter.get('/listings', ah(async (req, res) => {
  let qb = db.from('land_listings').select('*, profiles(display_name)');
  if (req.query.status) qb = qb.eq('status', req.query.status);
  res.json({ data: must(await qb.order('created_at', { ascending: false }).limit(200)) });
}));

// PATCH /api/admin/listings/:id { status?, verification_status? }
adminRouter.patch('/listings/:id', ah(async (req, res) => {
  const upd = {};
  if (req.body?.status) {
    if (!['pending', 'active', 'sold', 'rejected'].includes(req.body.status)) throw new HttpError(400, 'invalid status');
    upd.status = req.body.status;
  }
  if (req.body?.verification_status) {
    if (!['unverified', 'pending', 'verified', 'rejected'].includes(req.body.verification_status)) throw new HttpError(400, 'invalid verification_status');
    upd.verification_status = req.body.verification_status;
  }
  if (!Object.keys(upd).length) throw new HttpError(400, 'nothing to update');
  const row = must(await db.from('land_listings').update(upd).eq('id', req.params.id).select().maybeSingle());
  if (!row) throw new HttpError(404, 'Listing not found');
  await audit(req.user.id, 'listing.moderate', 'land_listings', row.id, upd);
  res.json({ data: row });
}));

adminRouter.get('/users', ah(async (_req, res) => {
  res.json({ data: must(await db.from('profiles').select('*').order('created_at', { ascending: false }).limit(200)) });
}));

// PATCH /api/admin/users/:id/role { role }
adminRouter.patch('/users/:id/role', ah(async (req, res) => {
  const role = req.body?.role;
  if (!['public', 'policymaker', 'admin'].includes(role)) throw new HttpError(400, 'invalid role');
  if (req.params.id === req.user.id) throw new HttpError(400, 'Admins cannot change their own role');
  const row = must(await db.from('profiles').update({ role }).eq('id', req.params.id).select().maybeSingle());
  if (!row) throw new HttpError(404, 'User not found');
  await audit(req.user.id, 'user.role_change', 'profiles', row.id, { role });
  res.json({ data: row });
}));

adminRouter.get('/audit-logs', ah(async (_req, res) => {
  res.json({ data: must(await db.from('audit_logs').select('*').order('created_at', { ascending: false }).limit(200)) });
}));

