import { Router } from 'express';
import { db, requireAuth } from '../lib/supabase.js';
import { ah, must, HttpError, DEMO_NOTICE } from '../lib/util.js';
import { ASSUMPTIONS, FORMULAS, validateInputs, runSimulation } from '../lib/simulator.js';

const r = Router();

// Anyone can open the policymaker portal in DEMO mode. Real 'policymaker' role is only granted by an admin.
const accessInfo = (user) => ({
  access_mode: user && ['policymaker', 'admin'].includes(user.role) ? user.role : 'demo',
  disclaimer: 'Demo mode does not verify government employment. Aggregate figures are illustrative where is_demo=true.',
});

// GET /api/policy/indicators?state=   -> rows + grouped by state
r.get('/indicators', ah(async (req, res) => {
  let qb = db.from('policy_indicators').select('id, indicator_name, state, district, metric_value, target_value, unit, period_start, is_demo, policies(title)');
  if (req.query.state) qb = qb.eq('state', req.query.state);
  const rows = must(await qb.order('state').order('indicator_name'));
  const byState = {};
  rows.forEach((x) => {
    (byState[x.state] ||= {})[x.indicator_name] = {
      value: Number(x.metric_value), target: Number(x.target_value), unit: x.unit,
      progress_pct: x.unit === '%' ? Number(x.metric_value) : Math.min(100, Math.round((100 * x.target_value) / x.metric_value)),
    };
  });
  res.json({ data: rows, by_state: byState, ...accessInfo(req.user), notice: DEMO_NOTICE });
}));

// GET /api/policy/summary -> KPI cards for the dashboard header
r.get('/summary', ah(async (req, res) => {
  const [ind, parcels, listings, schemes, policies] = await Promise.all([
    db.from('policy_indicators').select('indicator_name, metric_value, unit'),
    db.from('land_parcels').select('id', { count: 'exact', head: true }),
    db.from('land_listings').select('status'),
    db.from('government_schemes').select('id', { count: 'exact', head: true }),
    db.from('policies').select('id', { count: 'exact', head: true }),
  ]);
  const rows = must(ind);
  const avg = (name) => {
    const v = rows.filter((x) => x.indicator_name === name).map((x) => Number(x.metric_value));
    return v.length ? Math.round((v.reduce((a, b) => a + b, 0) / v.length) * 10) / 10 : null;
  };
  const ls = must(listings);
  res.json({
    kpis: {
      avg_records_computerised_pct: avg('Land records computerised'),
      avg_cadastral_digitised_pct: avg('Cadastral maps digitised'),
      avg_ulpin_pct: avg('Parcels with ULPIN assigned'),
      avg_dispute_days: avg('Avg. land dispute resolution time'),
      parcels_in_system: parcels.count ?? 0,
      active_listings: ls.filter((x) => x.status === 'active').length,
      pending_listings: ls.filter((x) => x.status === 'pending').length,
      schemes: schemes.count ?? 0,
      policies: policies.count ?? 0,
    },
    ...accessInfo(req.user),
  });
}));

// GET /api/policy/compare?states=Karnataka,Kerala  -> chart-ready comparison
r.get('/compare', ah(async (req, res) => {
  const states = String(req.query.states || '').split(',').map((s) => s.trim()).filter(Boolean).slice(0, 6);
  let qb = db.from('policy_indicators').select('indicator_name, state, metric_value, target_value, unit, is_demo');
  if (states.length) qb = qb.in('state', states);
  const rows = must(await qb);
  const indicators = [...new Set(rows.map((x) => x.indicator_name))];
  const chart = indicators.map((name) => {
    const point = { indicator: name, unit: rows.find((x) => x.indicator_name === name)?.unit };
    rows.filter((x) => x.indicator_name === name).forEach((x) => { point[x.state] = Number(x.metric_value); });
    return point;
  });
  res.json({ states: [...new Set(rows.map((x) => x.state))], chart, notice: DEMO_NOTICE });
}));

// GET /api/policy/simulator/config -> defaults, ranges, formulas (for building the form)
r.get('/simulator/config', (_req, res) => {
  res.json({
    inputs: {
      state: { type: 'select', default: 'Karnataka' },
      budget_crore: { type: 'number', min: 0, max: 1000, default: 50, label: 'Extra digitisation budget (Rs crore / year)' },
      years: { type: 'number', min: 1, max: 10, default: 5, label: 'Time horizon (years)' },
      stamp_duty_change_pp: { type: 'number', min: -3, max: 3, step: 0.5, default: 0, label: 'Stamp duty change (percentage points)' },
      courts_increase_pct: { type: 'number', min: 0, max: 200, default: 0, label: 'Increase in dispute resolution capacity (%)' },
      awareness_campaign: { type: 'boolean', default: false, label: 'Run public awareness campaign' },
    },
    formulas: FORMULAS, assumptions: ASSUMPTIONS,
  });
});

async function baselineFor(state) {
  const rows = must(await db.from('policy_indicators').select('indicator_name, metric_value').eq('state', state));
  if (!rows.length) throw new HttpError(404, `No indicator data for state "${state}"`);
  const get = (n, d) => Number(rows.find((x) => x.indicator_name === n)?.metric_value ?? d);
  return {
    records: get('Land records computerised', 90),
    cadastral: get('Cadastral maps digitised', 70),
    ulpin: get('Parcels with ULPIN assigned', 75),
    dispute_days: get('Avg. land dispute resolution time', 450),
  };
}

// POST /api/policy/simulate { state, budget_crore, years, stamp_duty_change_pp, courts_increase_pct, awareness_campaign, save?, scenario_name? }
r.post('/simulate', ah(async (req, res) => {
  const { inputs, errors } = validateInputs(req.body || {});
  if (errors.length) return res.status(400).json({ error: 'Validation failed', details: errors });
  const baseline = await baselineFor(inputs.state);
  const outputs = runSimulation(inputs, baseline);
  let saved = null;
  if (req.body?.save) {
    if (!req.user) throw new HttpError(401, 'Login required to save scenarios');
    const name = String(req.body.scenario_name || `${inputs.state} scenario`).slice(0, 120);
    saved = must(await db.from('simulation_runs').insert({
      user_id: req.user.id, scenario_name: name, inputs,
      outputs: { ...outputs, baseline_inputs: baseline }, assumptions: ASSUMPTIONS,
    }).select('id, scenario_name, created_at').single());
  }
  res.json({ inputs, baseline_inputs: baseline, outputs, formulas: FORMULAS, assumptions: ASSUMPTIONS, saved });
}));

// GET /api/policy/simulations -> my saved scenarios
r.get('/simulations', requireAuth, ah(async (req, res) => {
  res.json({ data: must(await db.from('simulation_runs').select('*').eq('user_id', req.user.id).order('created_at', { ascending: false }).limit(50)) });
}));

r.delete('/simulations/:id', requireAuth, ah(async (req, res) => {
  must(await db.from('simulation_runs').delete().eq('id', req.params.id).eq('user_id', req.user.id));
  res.json({ ok: true });
}));

export default r;
