// Drop this file into the frontend (e.g. src/lib/bhuminetApi.js).
// Works with React / Next.js / Vite / plain JS modules.
// Login stays on the frontend with Supabase Auth (ANON key). This file forwards the
// user's access token to the backend so the server can check their role.
import { createClient } from '@supabase/supabase-js';

// Vite uses import.meta.env.VITE_*, Next.js uses process.env.NEXT_PUBLIC_* (must be written literally).
const viteEnv = (typeof import.meta !== 'undefined' && import.meta.env) || {};
const nextEnv = typeof process !== 'undefined' ? {
  API: process.env.NEXT_PUBLIC_API_URL,
  URL: process.env.NEXT_PUBLIC_SUPABASE_URL,
  KEY: process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY,
} : {};
const API = viteEnv.VITE_API_URL || nextEnv.API || 'http://localhost:4000/api';
export const supabase = createClient(
  viteEnv.VITE_SUPABASE_URL || nextEnv.URL,
  viteEnv.VITE_SUPABASE_ANON_KEY || nextEnv.KEY,
);

async function call(path, { method = 'GET', body, query } = {}) {
  const { data: { session } } = await supabase.auth.getSession();
  const qs = query ? '?' + new URLSearchParams(Object.entries(query).filter(([, v]) => v !== undefined && v !== '')) : '';
  const res = await fetch(`${API}${path}${qs}`, {
    method,
    headers: {
      'Content-Type': 'application/json',
      ...(session ? { Authorization: `Bearer ${session.access_token}` } : {}),
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  const json = await res.json().catch(() => ({}));
  if (!res.ok) throw Object.assign(new Error(json.error || res.statusText), { status: res.status, details: json.details });
  return json;
}

export const api = {
  // auth (sign up / log in with supabase.auth.signUp / signInWithPassword, then:)
  me: () => call('/auth/me'),
  updateMe: (display_name) => call('/auth/me', { method: 'PATCH', body: { display_name } }),

  // land search + GIS
  searchParcels: (filters) => call('/parcels', { query: filters }),          // { q, state, district, land_type, min_area, max_area, page, limit }
  parcelFilters: () => call('/parcels/filters'),
  parcelsGeoJSON: (filters) => call('/parcels/geojson', { query: filters }), // pass straight to L.geoJSON(...)
  parcel: (ref) => call(`/parcels/${encodeURIComponent(ref)}`),
  mapLayers: () => call('/map-layers'),

  // listings
  listings: (filters) => call('/listings', { query: filters }),             // { q, min_price, max_price, mine: 'true' }
  listingsGeoJSON: () => call('/listings/geojson'),
  createListing: (data) => call('/listings', { method: 'POST', body: data }),
  deleteListing: (id) => call(`/listings/${id}`, { method: 'DELETE' }),

  // info
  schemes: (filters) => call('/schemes', { query: filters }),               // { q, state }
  scheme: (id) => call(`/schemes/${id}`),
  policies: (filters) => call('/policies', { query: filters }),
  documents: (filters) => call('/documents', { query: filters }),           // { q, type, tag }
  marketTrends: (filters) => call('/market-trends', { query: filters }),    // { state, district, land_type, metric }
  environmentalRisks: (filters) => call('/environmental-risks', { query: filters }),
  dataSources: () => call('/data-sources'),

  // tools
  convertArea: (value, unit) => call('/calculator/convert', { method: 'POST', body: { value, unit } }),
  estimateValue: (data) => call('/calculator/estimate', { method: 'POST', body: data }),
  chat: (message, conversation_id) => call('/chat', { method: 'POST', body: { message, conversation_id } }),
  search: (q) => call('/search', { query: { q } }),

  // policymaker portal
  policySummary: () => call('/policy/summary'),
  indicators: (state) => call('/policy/indicators', { query: { state } }),
  compareStates: (states) => call('/policy/compare', { query: { states: states.join(',') } }),
  simulatorConfig: () => call('/policy/simulator/config'),
  simulate: (inputs) => call('/policy/simulate', { method: 'POST', body: inputs }), // add save:true, scenario_name to store
  mySimulations: () => call('/policy/simulations'),

  // admin
  adminListings: (status) => call('/admin/listings', { query: { status } }),
  moderateListing: (id, upd) => call(`/admin/listings/${id}`, { method: 'PATCH', body: upd }),
  adminUsers: () => call('/admin/users'),
  setUserRole: (id, role) => call(`/admin/users/${id}/role`, { method: 'PATCH', body: { role } }),
  auditLogs: () => call('/admin/audit-logs'),
};
